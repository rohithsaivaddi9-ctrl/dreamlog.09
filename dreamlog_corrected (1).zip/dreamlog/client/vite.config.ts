import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'node:path';

// Run from the project root with `vite client` (see package.json scripts).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // The client imports shared logic from ../shared, which sits outside this folder.
    fs: { allow: [path.resolve(__dirname, '..')] },
    proxy: { '/api': 'http://localhost:3001' },
  },
  build: {
    outDir: path.resolve(__dirname, '../dist/client'),
    emptyOutDir: true,
  },
});
