import { useEffect, useRef } from 'react';
import { Chart, Legend, LinearScale, LineElement, PointElement, ScatterController, Tooltip } from 'chart.js';
import type { CurvePoint } from '../../../shared/types';

Chart.register(ScatterController, LinearScale, PointElement, LineElement, Tooltip, Legend);

function hourLabel(h: number): string {
  const wrapped = ((Math.round(h) % 24) + 24) % 24;
  return `${String(wrapped).padStart(2, '0')}:00`;
}

/** Caffeine left in the body across the day, with a vertical marker at bedtime. */
export function CaffeineChart({ curve, bedtimeHour, height = 220 }: { curve: CurvePoint[]; bedtimeHour: number; height?: number }) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const top = Math.max(100, ...curve.map((p) => p.mg)) * 1.1;
    const chart = new Chart(canvas, {
      type: 'scatter',
      data: {
        datasets: [
          {
            label: 'Caffeine in body (mg)',
            data: curve.map((p) => ({ x: p.hour, y: p.mg })),
            showLine: true,
            pointRadius: 0,
            borderColor: '#fbbf24',
            backgroundColor: '#fbbf24',
            borderWidth: 2.5,
            tension: 0.3,
          },
          {
            label: 'Bedtime',
            data: [
              { x: bedtimeHour, y: 0 },
              { x: bedtimeHour, y: top },
            ],
            showLine: true,
            pointRadius: 0,
            borderColor: '#60a5fa',
            borderWidth: 2,
            borderDash: [6, 4],
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            min: 6,
            max: 30,
            ticks: { color: '#cbd5e1', stepSize: 3, callback: (v) => hourLabel(Number(v)) },
            grid: { color: 'rgba(148,163,184,0.15)' },
          },
          y: {
            min: 0,
            max: top,
            title: { display: true, text: 'mg', color: '#cbd5e1' },
            ticks: { color: '#cbd5e1' },
            grid: { color: 'rgba(148,163,184,0.15)' },
          },
        },
        plugins: {
          legend: { labels: { color: '#cbd5e1', usePointStyle: true } },
          tooltip: {
            callbacks: {
              label: (ctx) =>
                ctx.datasetIndex === 0
                  ? `${hourLabel(ctx.parsed.x ?? 0)}: ${Math.round(ctx.parsed.y ?? 0)} mg`
                  : `Bedtime ${hourLabel(bedtimeHour)}`,
            },
          },
        },
      },
    });
    return () => chart.destroy();
  }, [curve, bedtimeHour]);

  return (
    <div style={{ height }} className="relative w-full">
      <canvas ref={canvasRef} role="img" aria-label="Caffeine remaining in the body through the day, with bedtime marked" />
    </div>
  );
}
