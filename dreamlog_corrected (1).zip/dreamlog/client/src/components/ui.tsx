import type { ReactNode } from 'react';

export const inputClass =
  'w-full rounded-lg border border-slate-600 bg-slate-900/70 px-3 py-2 text-slate-100 placeholder-slate-500 focus:border-amber-300 focus:outline-none focus:ring-1 focus:ring-amber-300';
export const primaryButton =
  'rounded-lg bg-amber-300 px-4 py-2 font-semibold text-slate-900 transition hover:bg-amber-200 disabled:cursor-not-allowed disabled:opacity-50';
export const ghostButton =
  'rounded-lg border border-slate-600 px-4 py-2 text-slate-200 transition hover:border-slate-400 hover:bg-slate-700/40 disabled:cursor-not-allowed disabled:opacity-50';

export const FOCUS_LABELS = ['Distracted', 'Low', 'Okay', 'Good', 'Deep Focus'];

export function focusText(n: number): string {
  return `${n}/5 - ${FOCUS_LABELS[n - 1] ?? ''}`;
}

export function Card({
  title,
  subtitle,
  action,
  children,
  className = '',
}: {
  title?: string;
  subtitle?: string;
  action?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section className={`rounded-2xl border border-slate-700/60 bg-slate-800/50 p-5 shadow-lg shadow-black/10 ${className}`}>
      {(title || action) && (
        <header className="mb-4 flex items-start justify-between gap-3">
          <div>
            {title && <h2 className="text-base font-semibold text-slate-100">{title}</h2>}
            {subtitle && <p className="mt-0.5 text-sm text-slate-400">{subtitle}</p>}
          </div>
          {action}
        </header>
      )}
      {children}
    </section>
  );
}

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1 block text-sm font-medium text-slate-300">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-slate-500">{hint}</span>}
    </label>
  );
}

export function Pill({ tone, children }: { tone: 'amber' | 'blue' | 'green' | 'red' | 'slate'; children: ReactNode }) {
  const tones = {
    amber: 'bg-amber-300/15 text-amber-200 ring-amber-300/30',
    blue: 'bg-sky-400/15 text-sky-200 ring-sky-400/30',
    green: 'bg-emerald-400/15 text-emerald-200 ring-emerald-400/30',
    red: 'bg-rose-400/15 text-rose-200 ring-rose-400/30',
    slate: 'bg-slate-600/30 text-slate-300 ring-slate-500/30',
  };
  return <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ring-1 ${tones[tone]}`}>{children}</span>;
}

export function StarRating({ value, onChange, label }: { value: number; onChange: (n: number) => void; label: string }) {
  return (
    <div role="radiogroup" aria-label={label} className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          role="radio"
          aria-checked={value === n}
          aria-label={`${n} star${n > 1 ? 's' : ''}`}
          onClick={() => onChange(n)}
          className={`text-3xl leading-none transition hover:scale-110 ${n <= value ? 'text-amber-300' : 'text-slate-600'}`}
        >
          ★
        </button>
      ))}
      <span className="ml-2 text-sm text-slate-400">{value}/5</span>
    </div>
  );
}

export function FocusPicker({ value, onChange }: { value: number; onChange: (n: number) => void }) {
  return (
    <div role="radiogroup" aria-label="Focus rating" className="grid grid-cols-5 gap-2">
      {[1, 2, 3, 4, 5].map((n) => (
        <button
          key={n}
          type="button"
          role="radio"
          aria-checked={value === n}
          onClick={() => onChange(n)}
          className={`rounded-lg border px-1 py-2 text-center transition ${
            value === n
              ? 'border-sky-400 bg-sky-400/20 text-sky-100'
              : 'border-slate-600 text-slate-300 hover:border-slate-400'
          }`}
        >
          <span className="block text-lg font-semibold">{n}</span>
          <span className="block text-[11px] leading-tight text-slate-400">{FOCUS_LABELS[n - 1]}</span>
        </button>
      ))}
    </div>
  );
}

export function ErrorNote({ children }: { children: ReactNode }) {
  return <p role="alert" className="rounded-lg border border-rose-400/40 bg-rose-400/10 px-3 py-2 text-sm text-rose-200">{children}</p>;
}

export function SuccessNote({ children }: { children: ReactNode }) {
  return <p role="status" className="rounded-lg border border-emerald-400/40 bg-emerald-400/10 px-3 py-2 text-sm text-emerald-200">{children}</p>;
}
