import { useEffect, useRef } from 'react';
import { Chart, Legend, LinearScale, LineElement, PointElement, ScatterController, Tooltip } from 'chart.js';
import type { Pair, Regression } from '../../../shared/types';
import { formatDateShort } from '../../../shared/dates';

Chart.register(ScatterController, LinearScale, PointElement, LineElement, Tooltip, Legend);

interface PointWithDate {
  x: number;
  y: number;
  date: string;
}

const PALETTES = {
  dark: { text: '#cbd5e1', grid: 'rgba(148,163,184,0.15)', point: 'rgba(96,165,250,0.85)', trend: '#fbbf24', latest: '#fde68a', latestBorder: '#f59e0b' },
  light: { text: '#334155', grid: 'rgba(100,116,139,0.2)', point: 'rgba(37,99,235,0.8)', trend: '#d97706', latest: '#fbbf24', latestBorder: '#92400e' },
};

/** Sleep hours (x) against focus rating (y) with the OLS trendline. The newest day is highlighted. */
export function ScatterChart({
  pairs,
  regression,
  latestDate,
  theme = 'dark',
  height = 340,
}: {
  pairs: Pair[];
  regression: Regression | null;
  latestDate: string | null;
  theme?: 'dark' | 'light';
  height?: number;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const c = PALETTES[theme];
    const toPoint = (p: Pair): PointWithDate => ({ x: p.sleepHours, y: p.focus, date: p.date });
    const earlier = pairs.filter((p) => p.date !== latestDate).map(toPoint);
    const newest = pairs.filter((p) => p.date === latestDate).map(toPoint);
    const trend = regression
      ? [4.5, 9.5].map((x) => ({ x, y: regression.intercept + regression.slope * x }))
      : [];

    const chart = new Chart(canvas, {
      type: 'scatter',
      data: {
        datasets: [
          {
            label: 'Trendline (linear regression)',
            data: trend,
            showLine: true,
            pointRadius: 0,
            borderColor: c.trend,
            borderWidth: 2.5,
            borderDash: [8, 5],
            order: 3,
          },
          {
            label: 'Earlier days',
            data: earlier,
            backgroundColor: c.point,
            pointRadius: 5,
            pointHoverRadius: 7,
            order: 2,
          },
          {
            label: 'Newest log',
            data: newest,
            backgroundColor: c.latest,
            borderColor: c.latestBorder,
            borderWidth: 3,
            pointRadius: 10,
            pointHoverRadius: 12,
            order: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          x: {
            min: 4,
            max: 10,
            title: { display: true, text: 'Hours slept', color: c.text },
            ticks: { color: c.text, stepSize: 1 },
            grid: { color: c.grid },
          },
          y: {
            min: 0.5,
            max: 5.5,
            title: { display: true, text: 'Study focus (1-5)', color: c.text },
            ticks: {
              color: c.text,
              stepSize: 1,
              callback: (value) => (Number.isInteger(Number(value)) && Number(value) >= 1 && Number(value) <= 5 ? String(value) : ''),
            },
            grid: { color: c.grid },
          },
        },
        plugins: {
          legend: { labels: { color: c.text, usePointStyle: true } },
          tooltip: {
            callbacks: {
              label: (ctx) => {
                const raw = ctx.raw as Partial<PointWithDate>;
                if (raw.date) return `${formatDateShort(raw.date)}: ${raw.x} h sleep, focus ${raw.y}/5`;
                return ctx.dataset.label ?? '';
              },
            },
          },
        },
      },
    });
    return () => chart.destroy();
  }, [pairs, regression, latestDate, theme]);

  return (
    <div style={{ height }} className="relative w-full">
      <canvas ref={canvasRef} role="img" aria-label="Scatter plot of hours slept against study focus rating with a trendline" />
    </div>
  );
}
