import { useMemo, useState } from 'react';
import { MAX_STUDY_HOURS, MIN_SLEEP_HOURS, planExamWeek } from '../../../shared/exam';
import { addDays, formatDateShort } from '../../../shared/dates';
import { formatClock12, parseTime } from '../../../shared/time';
import type { ExamSubject } from '../../../shared/types';
import { Card, ErrorNote, Field, Pill, ghostButton, inputClass } from '../components/ui';

interface SubjectRow {
  name: string;
  examDate: string;
  difficulty: 1 | 2 | 3;
}

export function PlannerPage({ today }: { today: string }) {
  const [startDate, setStartDate] = useState(today);
  const [days, setDays] = useState(7);
  const [wakeTime, setWakeTime] = useState('07:00');
  const [sleepHours, setSleepHours] = useState(8);
  const [rows, setRows] = useState<SubjectRow[]>([
    { name: 'Algorithms', examDate: addDays(today, 3), difficulty: 3 },
    { name: 'Calculus', examDate: addDays(today, 5), difficulty: 2 },
    { name: 'Databases', examDate: addDays(today, 6), difficulty: 2 },
  ]);

  const subjects: ExamSubject[] = rows
    .filter((r) => r.name.trim() !== '' && r.examDate !== '')
    .map((r) => ({ name: r.name.trim(), examDate: r.examDate, difficulty: r.difficulty }));

  const plan = useMemo(() => {
    if (parseTime(wakeTime) === null || !startDate) return null;
    return planExamWeek({ startDate, days, wakeTime, sleepHours, subjects });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startDate, days, wakeTime, sleepHours, JSON.stringify(subjects)]);

  function update(i: number, patch: Partial<SubjectRow>) {
    setRows(rows.map((r, idx) => (idx === i ? { ...r, ...patch } : r)));
  }

  return (
    <div className="space-y-5">
      <Card
        title="Exam week sleep preserver"
        subtitle={`A protective timetable: never more than ${MAX_STUDY_HOURS} study hours a day, never less than ${MIN_SLEEP_HOURS} hours of sleep.`}
        className="print:hidden"
      >
        <div className="grid gap-4 md:grid-cols-4">
          <Field label="Week starts">
            <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className={inputClass} />
          </Field>
          <Field label="Days to plan">
            <input type="number" min={1} max={14} value={days} onChange={(e) => setDays(Math.min(14, Math.max(1, Number(e.target.value) || 1)))} className={inputClass} />
          </Field>
          <Field label="Wake-up time">
            <input type="time" value={wakeTime} onChange={(e) => setWakeTime(e.target.value)} className={inputClass} />
          </Field>
          <Field label={`Sleep per night (${sleepHours} h)`} hint={`Minimum ${MIN_SLEEP_HOURS} h is enforced.`}>
            <input type="range" min={MIN_SLEEP_HOURS} max={10} step={0.5} value={sleepHours} onChange={(e) => setSleepHours(Number(e.target.value))} className="w-full accent-amber-300" />
          </Field>
        </div>

        <h3 className="mb-2 mt-6 text-sm font-medium text-slate-300">Exams</h3>
        <div className="space-y-2">
          {rows.map((r, i) => (
            <div key={i} className="grid grid-cols-[1fr_9rem_8rem_auto] items-center gap-2">
              <input aria-label="Subject name" value={r.name} onChange={(e) => update(i, { name: e.target.value })} placeholder="Subject" className={inputClass} />
              <input aria-label="Exam date" type="date" value={r.examDate} onChange={(e) => update(i, { examDate: e.target.value })} className={inputClass} />
              <select aria-label="Difficulty" value={r.difficulty} onChange={(e) => update(i, { difficulty: Number(e.target.value) as 1 | 2 | 3 })} className={inputClass}>
                <option value={1}>Easier</option>
                <option value={2}>Medium</option>
                <option value={3}>Hardest</option>
              </select>
              <button type="button" className="px-2 text-rose-300 hover:underline" onClick={() => setRows(rows.filter((_, idx) => idx !== i))} aria-label={`Remove ${r.name || 'subject'}`}>
                Remove
              </button>
            </div>
          ))}
        </div>
        <div className="mt-3 flex gap-3">
          <button type="button" className={ghostButton} onClick={() => setRows([...rows, { name: '', examDate: addDays(today, 4), difficulty: 2 }])}>
            Add exam
          </button>
          <button type="button" className={ghostButton} onClick={() => window.print()} disabled={!plan}>
            Print timetable
          </button>
        </div>
      </Card>

      {!plan ? (
        <ErrorNote>Choose a valid start date and wake-up time.</ErrorNote>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {plan.map((d) => (
            <Card key={d.date} className="print:break-inside-avoid">
              <div className="mb-2 flex items-start justify-between">
                <h3 className="font-semibold text-slate-100">{formatDateShort(d.date)}</h3>
                <div className="flex gap-1.5">
                  <Pill tone={d.studyHours > 0 ? 'blue' : 'slate'}>{d.studyHours} h study</Pill>
                  <Pill tone="amber">{d.sleepHours} h sleep</Pill>
                </div>
              </div>
              {d.exams.length > 0 && <p className="mb-2 text-sm font-medium text-amber-300">Exam today: {d.exams.join(', ')}</p>}
              <p className="mb-3 text-xs text-slate-400">
                Wake {formatClock12(d.wakeTime)} · In bed by {formatClock12(d.bedtime)}
              </p>
              {d.blocks.length > 0 && (
                <ul className="mb-3 space-y-1 text-sm">
                  {d.blocks.map((b, idx) => (
                    <li key={idx} className="flex justify-between rounded bg-slate-900/50 px-2 py-1">
                      <span className="text-slate-300">{formatClock12(b.start)} – {formatClock12(b.end)}</span>
                      <span className="text-slate-100">{b.subject}</span>
                    </li>
                  ))}
                </ul>
              )}
              <p className="text-xs text-slate-400">{d.note}</p>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
