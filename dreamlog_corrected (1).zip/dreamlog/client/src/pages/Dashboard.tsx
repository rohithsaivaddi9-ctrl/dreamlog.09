import { useEffect, useState } from 'react';
import type { AnalyticsResponse, CaffeineStatusResponse } from '../../../shared/types';
import type { ForecastResponse } from '../../../shared/types';
import { recommendBedtimes } from '../../../shared/bedtime';
import { formatDateShort, weekdayShort } from '../../../shared/dates';
import { formatR } from '../../../shared/stats';
import { formatClock12, parseTime } from '../../../shared/time';
import { api } from '../lib/api';
import { CaffeineChart } from '../components/CaffeineChart';
import { ScatterChart } from '../components/ScatterChart';
import { Card, ErrorNote, Pill, inputClass, primaryButton } from '../components/ui';

interface Props {
  data: AnalyticsResponse;
  reload: () => Promise<unknown>;
  go: (route: 'log') => void;
}

export function Dashboard({ data, reload, go }: Props) {
  if (data.pairs.length === 0 && data.debt.nightsLogged === 0) {
    return (
      <Card title="No logs yet" subtitle="Log a night of sleep and a day of study to see your correlation.">
        <button className={primaryButton} onClick={() => go('log')}>
          Log your first night
        </button>
      </Card>
    );
  }
  return (
    <div className="grid gap-5 lg:grid-cols-3">
      <CorrelationCard data={data} />
      <Card
        title="Sleep vs. study focus"
        subtitle="Each dot is one day: hours slept the night before against that day's focus rating."
        className="lg:col-span-2 lg:row-span-2"
      >
        <ScatterChart pairs={data.pairs} regression={data.current.regression} latestDate={data.latest?.date ?? null} />
      </Card>
      <SleepDebtCard data={data} reload={reload} />
      <InsightsCard data={data} />
      <BedtimeCard data={data} />
      <ForecastCard data={data} />
      <CaffeineCard data={data} go={go} />
    </div>
  );
}

function CorrelationCard({ data }: { data: AnalyticsResponse }) {
  const { current, previous, latest } = data;
  const delta = previous && previous.r !== null && current.r !== null ? current.r - previous.r : null;
  return (
    <Card title="Correlation engine" subtitle="Pearson r between sleep duration and focus rating">
      <div className="flex items-end gap-3">
        <span className="text-5xl font-bold tracking-tight text-amber-300" aria-label="Pearson correlation coefficient">
          r = {formatR(current.r)}
        </span>
      </div>
      <p className="mt-2 text-lg font-medium text-slate-100">{current.label}</p>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Pill tone="slate">{current.n} days of data</Pill>
        {current.notice ? <Pill tone="amber">{current.notice}</Pill> : <Pill tone="green">Enough data for a stable estimate</Pill>}
      </div>
      {current.rSquared !== null && (
        <p className="mt-3 text-sm text-slate-400">
          Sleep explains about <strong className="text-slate-200">{Math.round(current.rSquared * 100)}%</strong> of the variation in your focus ratings.
        </p>
      )}
      {latest && previous && delta !== null && (
        <p className="mt-3 rounded-lg bg-slate-900/60 px-3 py-2 text-sm text-slate-300">
          Newest day ({formatDateShort(latest.date)}, {latest.sleepHours} h, focus {latest.focus}/5){' '}
          {Math.abs(delta) < 0.005 ? (
            <>left r unchanged at <strong>{formatR(current.r)}</strong>.</>
          ) : (
            <>
              moved r from <strong>{formatR(previous.r)}</strong> to <strong className="text-amber-300">{formatR(current.r)}</strong>{' '}
              <span className={delta > 0 ? 'text-emerald-300' : 'text-rose-300'}>{delta > 0 ? '▲' : '▼'}</span>.
            </>
          )}
        </p>
      )}
      <p className="mt-3 text-xs text-slate-500">Correlation shows a pattern in your own logs. It does not prove that sleep causes the change in focus.</p>
    </Card>
  );
}

function SleepDebtCard({ data, reload }: { data: AnalyticsResponse; reload: () => Promise<unknown> }) {
  const { debt } = data;
  const [targetText, setTargetText] = useState(String(data.sleepTarget));
  const [error, setError] = useState<string | null>(null);

  useEffect(() => setTargetText(String(data.sleepTarget)), [data.sleepTarget]);

  async function commit() {
    const value = Number(targetText);
    if (!Number.isFinite(value) || value === data.sleepTarget) return;
    try {
      await api.saveSleepTarget(value);
      setError(null);
      await reload();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not save target');
      setTargetText(String(data.sleepTarget));
    }
  }

  const levelPill = {
    'on-track': <Pill tone="green">On track</Pill>,
    mild: <Pill tone="amber">Mild debt</Pill>,
    significant: <Pill tone="red">Significant debt</Pill>,
    unknown: <Pill tone="slate">No data</Pill>,
  }[debt.level];

  return (
    <Card title="Sleep debt" subtitle={`Last ${debt.windowDays} nights against your nightly target`} action={levelPill}>
      <div className="flex items-baseline gap-2">
        <span className="text-4xl font-bold text-slate-100">{debt.shortfall.toFixed(1)}</span>
        <span className="text-slate-400">hours short</span>
      </div>
      {debt.surplus > 0 && <p className="text-xs text-slate-500">You banked {debt.surplus.toFixed(1)} h on longer nights; shortfall isn't offset by these.</p>}
      <div className="mt-4 flex h-28 items-end gap-2" role="img" aria-label="Hours slept each of the last seven nights">
        {debt.nights.map((n) => {
          const pct = n.hours === null ? 0 : Math.min(100, (n.hours / Math.max(debt.target, 9)) * 100);
          return (
            <div key={n.date} className="flex flex-1 flex-col items-center gap-1">
              <span className="text-[11px] text-slate-400">{n.hours === null ? '–' : n.hours}</span>
              <div className="flex h-20 w-full items-end rounded bg-slate-900/60">
                <div
                  className={`w-full rounded ${n.hours !== null && n.hours >= debt.target ? 'bg-sky-400' : 'bg-amber-300'}`}
                  style={{ height: `${pct}%` }}
                />
              </div>
              <span className="text-[11px] text-slate-500">{weekdayShort(n.date)}</span>
            </div>
          );
        })}
      </div>
      <div className="mt-4 flex items-center gap-2 text-sm">
        <label htmlFor="target" className="text-slate-400">Nightly target</label>
        <input
          id="target"
          type="number"
          min={4}
          max={12}
          step={0.25}
          value={targetText}
          onChange={(e) => setTargetText(e.target.value)}
          onBlur={() => void commit()}
          onKeyDown={(e) => e.key === 'Enter' && e.currentTarget.blur()}
          className={`${inputClass} w-20 py-1`}
        />
        <span className="text-slate-400">hours</span>
      </div>
      {error && <div className="mt-2"><ErrorNote>{error}</ErrorNote></div>}
    </Card>
  );
}

function InsightsCard({ data }: { data: AnalyticsResponse }) {
  const border = { positive: 'border-emerald-400', warning: 'border-amber-300', info: 'border-sky-400' };
  return (
    <Card title="Weekly optimization insights" subtitle="Built from your own logged days" className="lg:col-span-2">
      {data.insights.length === 0 ? (
        <p className="text-sm text-slate-400">Log a few more days with both sleep and study to unlock insights.</p>
      ) : (
        <ul className="space-y-3">
          {data.insights.map((i) => (
            <li key={i.id} className={`border-l-4 ${border[i.tone]} bg-slate-900/50 py-2 pl-3 pr-2 text-sm text-slate-200`}>
              {i.text}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

function BedtimeCard({ data }: { data: AnalyticsResponse }) {
  const [wake, setWake] = useState(data.bedtime.suggestedWake);
  const valid = parseTime(wake) !== null;
  const options = valid ? recommendBedtimes(wake, data.sleepTarget) : [];
  return (
    <Card title="Optimal bedtime" subtitle="Wake at the end of a 90-minute sleep cycle, not in the middle of deep sleep">
      <label className="flex items-center gap-3 text-sm text-slate-300">
        I need to wake up at
        <input type="time" value={wake} onChange={(e) => setWake(e.target.value)} className={`${inputClass} w-32`} />
      </label>
      <ul className="mt-4 space-y-2">
        {options.map((o) => (
          <li
            key={o.cycles}
            className={`flex items-center justify-between rounded-lg border px-3 py-2 ${
              o.recommended ? 'border-amber-300/60 bg-amber-300/10' : 'border-slate-700 bg-slate-900/40'
            }`}
          >
            <span className="text-lg font-semibold text-slate-100">{formatClock12(o.bedtime)}</span>
            <span className="text-sm text-slate-400">
              {o.cycles} cycles · {o.sleepHours} h {o.recommended && <Pill tone="amber">Best fit</Pill>}
            </span>
          </li>
        ))}
      </ul>
      <p className="mt-3 text-xs text-slate-500">Includes about 15 minutes to fall asleep. Best fit is closest to your {data.sleepTarget} h target.</p>
    </Card>
  );
}

function CaffeineCard({ data, go }: { data: AnalyticsResponse; go: (route: 'log') => void }) {
  const defaultBed = data.bedtime.options.find((o) => o.recommended)?.bedtime ?? '23:30';
  const [date, setDate] = useState(data.today);
  const [bedtime, setBedtime] = useState(defaultBed);
  const [status, setStatus] = useState<CaffeineStatusResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (parseTime(bedtime) === null || !date) return;
    let cancelled = false;
    api
      .caffeineStatus(date, bedtime)
      .then((s) => {
        if (!cancelled) {
          setStatus(s);
          setError(null);
        }
      })
      .catch((e: unknown) => !cancelled && setError(e instanceof Error ? e.message : 'Could not load caffeine'));
    return () => {
      cancelled = true;
    };
  }, [date, bedtime]);

  return (
    <Card
      title="Caffeine at bedtime"
      subtitle="Half-life of about 5 hours"
      className="lg:col-span-3"
      action={<button className="text-sm text-amber-300 hover:underline" onClick={() => go('log')}>Log caffeine →</button>}
    >
      <div className="mb-3 flex flex-wrap items-center gap-3 text-sm text-slate-300">
        <label className="flex items-center gap-2">Day <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={`${inputClass} w-40 py-1`} /></label>
        <label className="flex items-center gap-2">Bedtime <input type="time" value={bedtime} onChange={(e) => setBedtime(e.target.value)} className={`${inputClass} w-32 py-1`} /></label>
      </div>
      {error && <ErrorNote>{error}</ErrorNote>}
      {status && (
        <>
          <CaffeineChart curve={status.curve} bedtimeHour={status.bedtimeHour} />
          <p className="mt-3 text-sm text-slate-300">{status.message}</p>
          {status.doses.length === 0 && <p className="mt-1 text-xs text-slate-500">Nothing logged for this day. Try yesterday, or add a drink on the Log page.</p>}
        </>
      )}
    </Card>
  );
}

/** Next-3-nights sleep forecast (Holt smoothing) plus robust anomaly flags. */
function ForecastCard({ data }: { data: AnalyticsResponse }) {
  const [fc, setFc] = useState<ForecastResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    api
      .forecast(data.today)
      .then((r) => !cancelled && setFc(r))
      .catch((e: Error) => !cancelled && setError(e.message));
    return () => {
      cancelled = true;
    };
  }, [data]);

  return (
    <Card title="Sleep forecast" subtitle="Trend model of your next 3 nights, with unusual nights flagged" className="lg:col-span-3">
      {error && <ErrorNote>{error}</ErrorNote>}
      {fc && (
        <>
          <div className="grid gap-3 sm:grid-cols-3">
            {fc.nextNights.map((n, i) => (
              <div key={n.date} className="rounded-lg bg-slate-800/60 p-3">
                <p className="text-xs text-slate-400">{weekdayShort(n.date)} {formatDateShort(n.date)}</p>
                <p className="text-2xl font-bold text-slate-100">{n.value.toFixed(1)} h</p>
                <p className="text-xs text-slate-500">likely {n.low.toFixed(1)}–{n.high.toFixed(1)} h · debt {fc.projectedDebt[i].toFixed(1)} h</p>
              </div>
            ))}
          </div>
          <p className="mt-3 text-sm text-slate-300">{fc.message}</p>
          {fc.anomalies.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-2">
              {fc.anomalies.map((a) => (
                <Pill key={a.date} tone={a.direction === 'low' ? 'red' : 'blue'}>
                  Unusual night {formatDateShort(a.date)}: {a.value.toFixed(1)} h
                </Pill>
              ))}
            </div>
          )}
        </>
      )}
    </Card>
  );
}
