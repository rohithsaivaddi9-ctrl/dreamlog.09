import { useCallback, useEffect, useState } from 'react';
import type { AnalyticsResponse } from '../../shared/types';
import { todayISO } from '../../shared/dates';
import { api } from './lib/api';
import { Dashboard } from './pages/Dashboard';
import { HistoryPage } from './pages/HistoryPage';
import { LogPage } from './pages/LogPage';
import { PlannerPage } from './pages/PlannerPage';
import { ReportPage } from './pages/ReportPage';
import { ErrorNote } from './components/ui';

type Route = 'dashboard' | 'log' | 'planner' | 'history' | 'report';

const NAV: { route: Route; label: string }[] = [
  { route: 'dashboard', label: 'Dashboard' },
  { route: 'log', label: 'Log' },
  { route: 'planner', label: 'Exam week' },
  { route: 'history', label: 'History' },
  { route: 'report', label: 'Report' },
];

function readRoute(): Route {
  const hash = window.location.hash.replace(/^#\/?/, '');
  return NAV.some((n) => n.route === hash) ? (hash as Route) : 'dashboard';
}

export default function App() {
  const [route, setRoute] = useState<Route>(readRoute);
  const [data, setData] = useState<AnalyticsResponse | null>(null);
  const [error, setError] = useState<string | null>(null);
  const today = todayISO();

  useEffect(() => {
    const onHash = () => setRoute(readRoute());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const go = useCallback((r: Route) => {
    window.location.hash = `/${r}`;
  }, []);

  const reload = useCallback(async (): Promise<AnalyticsResponse | null> => {
    try {
      const next = await api.analytics(todayISO());
      setData(next);
      setError(null);
      return next;
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not load data');
      return null;
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  return (
    <div className="min-h-screen bg-night">
      <header className="border-b border-slate-800 bg-night/95 print:hidden">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-3">
          <button onClick={() => go('dashboard')} className="flex items-center gap-2 text-xl font-bold text-slate-100">
            <span aria-hidden className="text-amber-300">🌙</span> DreamLog
            <span className="hidden text-sm font-normal text-slate-500 sm:inline">sleep better, study smarter</span>
          </button>
          <nav className="flex gap-1" aria-label="Main">
            {NAV.map((n) => (
              <button
                key={n.route}
                onClick={() => go(n.route)}
                aria-current={route === n.route ? 'page' : undefined}
                className={`rounded-lg px-3 py-1.5 text-sm font-medium transition ${
                  route === n.route ? 'bg-amber-300/15 text-amber-200' : 'text-slate-400 hover:bg-slate-800 hover:text-slate-100'
                }`}
              >
                {n.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6 print:max-w-none print:p-0">
        {error && (
          <div className="mb-4">
            <ErrorNote>{error}</ErrorNote>
          </div>
        )}
        {route === 'dashboard' && (data ? <Dashboard data={data} reload={reload} go={go} /> : !error && <p className="text-slate-400">Loading…</p>)}
        {route === 'log' && <LogPage today={today} reload={reload} go={go} />}
        {route === 'planner' && <PlannerPage today={today} />}
        {route === 'history' && <HistoryPage today={today} reload={reload} />}
        {route === 'report' && <ReportPage today={today} />}
      </main>
    </div>
  );
}
