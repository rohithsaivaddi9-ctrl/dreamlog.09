// Shared types used by the server, the React client and the tests.

/** One night of sleep. `date` is the morning you woke up (YYYY-MM-DD). */
export interface SleepLog {
  date: string;
  bedtime: string; // HH:MM, 24 h
  wakeTime: string; // HH:MM, 24 h
  durationHours: number;
  quality: number; // 1-5 stars
}

/** One day of studying. `date` is the day you studied (YYYY-MM-DD). */
export interface StudyLog {
  date: string;
  hoursStudied: number;
  subjects: string[];
  focus: number; // 1-5
  score: number | null; // optional quiz / exam score, 0-100
}

export interface CaffeineLog {
  id: number;
  date: string;
  time: string; // HH:MM
  drink: string;
  mg: number;
}

/** A day that has both a sleep log and a study log: one point on the scatter plot. */
export interface Pair {
  date: string;
  sleepHours: number;
  focus: number;
  quality: number;
  hoursStudied: number;
  score: number | null;
}

export interface Regression {
  slope: number;
  intercept: number;
}

export type CorrelationStrength = 'Strong' | 'Moderate' | 'Weak' | 'None';

export interface CorrelationResult {
  n: number;
  r: number | null;
  rSquared: number | null;
  /** e.g. "Strong Positive Correlation" */
  label: string;
  strength: CorrelationStrength;
  /** true once there are at least MIN_DAYS paired days */
  sufficient: boolean;
  /** helper text shown while there is too little data, otherwise null */
  notice: string | null;
  regression: Regression | null;
}

export interface SleepDebtNight {
  date: string;
  hours: number | null; // null = nothing logged that night
  deficit: number;
}

export interface SleepDebt {
  target: number;
  windowDays: number;
  endDate: string | null;
  nights: SleepDebtNight[];
  nightsLogged: number;
  /** total hours below target, summed over nights that fell short */
  shortfall: number;
  /** total hours above target on nights that went over */
  surplus: number;
  /** surplus - shortfall (negative = behind) */
  net: number;
  level: 'on-track' | 'mild' | 'significant' | 'unknown';
}

export interface Insight {
  id: string;
  tone: 'positive' | 'warning' | 'info';
  text: string;
}

export interface BedtimeOption {
  cycles: number;
  sleepHours: number;
  bedtime: string; // HH:MM
  recommended: boolean;
}

export interface CaffeineDose {
  time: string; // HH:MM
  mg: number;
}

export interface CurvePoint {
  /** hours since midnight of the logged day (can exceed 24 for after-midnight) */
  hour: number;
  mg: number;
}

export type Validated<T> = { ok: true; value: T } | { ok: false; errors: string[] };

export interface SleepInput {
  date: string;
  bedtime: string;
  wakeTime: string;
  quality: number;
  durationHours: number;
}

export interface StudyInput {
  date: string;
  hoursStudied: number;
  subjects: string[];
  focus: number;
  score: number | null;
}

export interface CaffeineInput {
  date: string;
  time: string;
  drink: string;
  mg: number;
}

export interface ExamSubject {
  name: string;
  examDate: string;
  difficulty: 1 | 2 | 3;
}

export interface ExamPlanInput {
  startDate: string;
  days: number;
  wakeTime: string;
  sleepHours: number;
  subjects: ExamSubject[];
  maxStudyHours?: number;
}

export interface StudyBlock {
  subject: string;
  start: string;
  end: string;
  hours: number;
}

export interface PlanDay {
  date: string;
  wakeTime: string;
  bedtime: string;
  sleepHours: number;
  studyHours: number;
  blocks: StudyBlock[];
  exams: string[];
  note: string;
}

// ---- API responses ----

export interface AnalyticsResponse {
  today: string;
  sleepTarget: number;
  pairs: Pair[];
  current: CorrelationResult;
  /** correlation with the newest paired day left out, to show how the newest log moved r */
  previous: CorrelationResult | null;
  latest: Pair | null;
  debt: SleepDebt;
  insights: Insight[];
  bedtime: { suggestedWake: string; options: BedtimeOption[] };
}

export interface CaffeineStatusResponse {
  date: string;
  bedtime: string;
  doses: CaffeineLog[];
  curve: CurvePoint[];
  bedtimeHour: number;
  mgAtBedtime: number;
  level: 'none' | 'minimal' | 'moderate' | 'high';
  message: string;
}

export interface ExamScoreRow {
  date: string;
  subjects: string[];
  score: number;
  sleepHours: number | null;
  focus: number;
}

export interface ReportResponse {
  generatedOn: string;
  periodStart: string | null;
  periodEnd: string | null;
  daysLogged: number;
  avgSleep: number | null;
  avgFocus: number | null;
  avgStudy: number | null;
  sleepTarget: number;
  debt: SleepDebt;
  correlation: CorrelationResult;
  pairs: Pair[];
  latest: Pair | null;
  examScores: ExamScoreRow[];
  examCorrelation: CorrelationResult | null;
  insights: Insight[];
}

import type { Anomaly, ForecastPoint } from './forecast';

/** Response of GET /api/forecast. */
export interface ForecastResponse {
  today: string;
  sleepTarget: number;
  basedOnNights: number;
  nextNights: (ForecastPoint & { date: string })[];
  projectedDebt: number[];
  anomalies: (Anomaly & { date: string })[];
  message: string;
}
