import { mean, analyzePairs } from './stats';
import type { Insight, Pair, SleepDebt } from './types';

export const HIGH_SLEEP_THRESHOLD = 7.5;
export const SHORT_SLEEP_THRESHOLD = 6;

const MIN_GROUP = 2;

function avgFocus(pairs: Pair[]): number {
  return mean(pairs.map((p) => p.focus));
}

/** Evidence-based messages built only from the student's own logged days. */
export function generateInsights(pairs: Pair[], debt: SleepDebt): Insight[] {
  const insights: Insight[] = [];

  // 1. Well-rested days vs the rest.
  const rested = pairs.filter((p) => p.sleepHours >= HIGH_SLEEP_THRESHOLD);
  const other = pairs.filter((p) => p.sleepHours < HIGH_SLEEP_THRESHOLD);
  if (rested.length >= MIN_GROUP && other.length >= MIN_GROUP) {
    const a = avgFocus(rested);
    const b = avgFocus(other);
    const pct = Math.round(((a - b) / b) * 100);
    const detail = `(average focus ${a.toFixed(1)} vs ${b.toFixed(1)} out of 5)`;
    if (pct > 0) {
      insights.push({
        id: 'rested-vs-other',
        tone: 'positive',
        text: `Days following ${HIGH_SLEEP_THRESHOLD}+ hours of sleep saw ${pct}% higher study focus ${detail}.`,
      });
    } else if (pct < 0) {
      insights.push({
        id: 'rested-vs-other',
        tone: 'info',
        text: `Days following ${HIGH_SLEEP_THRESHOLD}+ hours of sleep saw ${Math.abs(pct)}% lower study focus ${detail}. Your data doesn't show a sleep benefit yet.`,
      });
    } else {
      insights.push({
        id: 'rested-vs-other',
        tone: 'info',
        text: `Focus was the same on days after ${HIGH_SLEEP_THRESHOLD}+ hours of sleep and on other days ${detail}.`,
      });
    }
  }

  // 2. Short nights.
  const short = pairs.filter((p) => p.sleepHours < SHORT_SLEEP_THRESHOLD);
  const notShort = pairs.filter((p) => p.sleepHours >= SHORT_SLEEP_THRESHOLD);
  if (short.length >= MIN_GROUP && notShort.length >= MIN_GROUP) {
    insights.push({
      id: 'short-nights',
      tone: avgFocus(short) < avgFocus(notShort) ? 'warning' : 'info',
      text: `After nights under ${SHORT_SLEEP_THRESHOLD} hours your focus averaged ${avgFocus(short).toFixed(1)}/5, compared with ${avgFocus(notShort).toFixed(1)}/5 after longer nights.`,
    });
  }

  // 3. Where focus peaks.
  const buckets = new Map<number, Pair[]>();
  for (const p of pairs) {
    const key = Math.round(p.sleepHours);
    buckets.set(key, [...(buckets.get(key) ?? []), p]);
  }
  const eligible = [...buckets.entries()].filter(([, ps]) => ps.length >= MIN_GROUP);
  if (eligible.length >= 2) {
    const [hours, ps] = eligible.reduce((best, cur) => (avgFocus(cur[1]) > avgFocus(best[1]) ? cur : best));
    insights.push({
      id: 'best-range',
      tone: 'info',
      text: `Your focus peaks after about ${hours} hours of sleep (average ${avgFocus(ps).toFixed(1)}/5 across ${ps.length} days).`,
    });
  }

  // 4. What the trendline says.
  const stats = analyzePairs(pairs);
  if (stats.sufficient && stats.r !== null && stats.regression && stats.rSquared !== null) {
    const slope = stats.regression.slope;
    const direction = slope >= 0 ? 'more' : 'less';
    insights.push({
      id: 'trendline',
      tone: 'info',
      text: `On your trendline each extra hour of sleep goes with ${Math.abs(slope).toFixed(2)} ${direction} focus points, and sleep accounts for about ${Math.round(stats.rSquared * 100)}% of the variation in your focus ratings.`,
    });
  }

  // 5. Sleep debt.
  if (debt.level !== 'unknown') {
    if (debt.shortfall > 1) {
      const nights = Math.ceil(debt.shortfall / 0.5);
      insights.push({
        id: 'sleep-debt',
        tone: 'warning',
        text: `You are ${debt.shortfall.toFixed(1)} hours short of your ${debt.target}-hour target over the last ${debt.windowDays} nights. Adding 30 minutes a night would clear it in ${nights} nights.`,
      });
    } else {
      insights.push({
        id: 'sleep-debt',
        tone: 'positive',
        text: `You are within about an hour of your ${debt.target}-hour target over the last ${debt.windowDays} nights. Keep it up.`,
      });
    }
  }

  return insights;
}
