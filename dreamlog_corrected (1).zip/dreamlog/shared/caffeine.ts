import { parseTime } from './time';
import type { CaffeineDose, CurvePoint } from './types';

/** Caffeine's half-life in healthy adults averages about 5 hours (it varies by person). */
export const HALF_LIFE_HOURS = 5;

/** Typical amounts, in mg per serving. Rough averages the student can edit. */
export const DRINK_PRESETS: { drink: string; mg: number }[] = [
  { drink: 'Brewed coffee (cup)', mg: 95 },
  { drink: 'Espresso (shot)', mg: 63 },
  { drink: 'Black tea (cup)', mg: 47 },
  { drink: 'Green tea (cup)', mg: 28 },
  { drink: 'Cola (can)', mg: 34 },
  { drink: 'Energy drink (can)', mg: 80 },
];

/** Hour-of-day number for a bedtime, treating small hours (00:30) as after midnight (24.5). */
export function bedtimeHour(bedtime: string): number {
  const mins = parseTime(bedtime);
  if (mins === null) throw new Error('Bedtime must be in HH:MM format');
  const hour = mins / 60;
  return hour < 12 ? hour + 24 : hour;
}

/** Caffeine (mg) still active at `atHour` (hours since midnight), from doses taken earlier. */
export function caffeineRemaining(doses: CaffeineDose[], atHour: number): number {
  let total = 0;
  for (const dose of doses) {
    const mins = parseTime(dose.time);
    if (mins === null) continue;
    const elapsed = atHour - mins / 60;
    if (elapsed < 0) continue;
    total += dose.mg * Math.pow(0.5, elapsed / HALF_LIFE_HOURS);
  }
  return total;
}

/** The decay curve across the day, one point every `stepHours`. */
export function caffeineCurve(doses: CaffeineDose[], fromHour = 6, toHour = 30, stepHours = 0.5): CurvePoint[] {
  const points: CurvePoint[] = [];
  for (let h = fromHour; h <= toHour + 1e-9; h += stepHours) {
    points.push({ hour: h, mg: Math.round(caffeineRemaining(doses, h) * 10) / 10 });
  }
  return points;
}

export function caffeineLevel(mg: number): 'none' | 'minimal' | 'moderate' | 'high' {
  if (mg < 1) return 'none';
  if (mg < 25) return 'minimal';
  if (mg < 75) return 'moderate';
  return 'high';
}

export function caffeineMessage(mg: number): string {
  const rounded = Math.round(mg);
  switch (caffeineLevel(mg)) {
    case 'none':
      return 'No caffeine logged that is still active at bedtime.';
    case 'minimal':
      return `About ${rounded} mg will still be in your body at bedtime. That is a small amount.`;
    case 'moderate':
      return `About ${rounded} mg will still be in your body at bedtime. It may make it harder to fall asleep.`;
    default:
      return `About ${rounded} mg will still be in your body at bedtime, close to a full cup of coffee. Consider an earlier last cup tomorrow.`;
  }
}
