import { addDays, daysBetween } from './dates';
import { formatTime, parseTime } from './time';
import type { ExamPlanInput, PlanDay, StudyBlock } from './types';

/** Hard limits the planner always respects. */
export const MAX_STUDY_HOURS = 8;
export const MIN_SLEEP_HOURS = 7;

const BLOCK_MINUTES = 90;
const SHORT_BREAK = 15;
const LUNCH_BREAK = 60;
const MORNING_ROUTINE = 120; // wake-up to first study block
const WIND_DOWN = 120; // last study block ends this long before bedtime
const QUANTUM = 15;

/** Split `totalMin` across subjects in proportion to `weights`, in 15-minute steps. */
function allocate(totalMin: number, weights: number[]): number[] {
  const sum = weights.reduce((a, b) => a + b, 0);
  const raw = weights.map((w) => (totalMin * w) / sum);
  const base = raw.map((x) => Math.floor(x / QUANTUM) * QUANTUM);
  let remaining = totalMin - base.reduce((a, b) => a + b, 0);
  const order = raw.map((x, i) => i).sort((i, j) => raw[j] - base[j] - (raw[i] - base[i]));
  let k = 0;
  while (remaining >= QUANTUM && order.length > 0) {
    base[order[k % order.length]] += QUANTUM;
    remaining -= QUANTUM;
    k++;
  }
  return base;
}

const MIN_SUBJECT_MINUTES = 30;

/** Split study minutes into similar-sized blocks of at most 90 minutes (e.g. 105 -> 60 + 45). */
function splitIntoBlocks(minutes: number): number[] {
  const count = Math.ceil(minutes / BLOCK_MINUTES);
  const out: number[] = [];
  let left = minutes;
  for (let i = count; i >= 1; i--) {
    const take = Math.min(left, Math.ceil(left / i / QUANTUM) * QUANTUM);
    out.push(take);
    left -= take;
  }
  return out;
}

/**
 * Builds a protective study timetable for exam week.
 *  - study is capped at 8 hours per day (never more, even if asked)
 *  - sleep is never planned below 7 hours (the planner raises lower requests to 7)
 *  - the day before an exam is capped at 6 hours, exam day at 2 hours of light review
 *  - time goes to the subjects whose exams are closest and hardest first
 *  - study blocks are 90 minutes with breaks, finishing 2 hours before bedtime
 */
export function planExamWeek(input: ExamPlanInput): PlanDay[] {
  const sleepHours = Math.min(10, Math.max(MIN_SLEEP_HOURS, Number.isFinite(input.sleepHours) ? input.sleepHours : 8));
  const maxStudy = Math.min(MAX_STUDY_HOURS, Math.max(0, input.maxStudyHours ?? MAX_STUDY_HOURS));
  const dayCount = Math.min(14, Math.max(1, Math.floor(input.days)));
  const wake = parseTime(input.wakeTime);
  if (wake === null) throw new Error('Wake time must be in HH:MM format');

  const bedtimeAbs = wake + 24 * 60 - Math.round(sleepHours * 60); // minutes after the day's midnight
  const studyStart = wake + MORNING_ROUTINE;
  const studyLimit = bedtimeAbs - WIND_DOWN;
  const bedtime = formatTime(bedtimeAbs);

  const days: PlanDay[] = [];
  for (let d = 0; d < dayCount; d++) {
    const date = addDays(input.startDate, d);
    const upcoming = input.subjects
      .map((s) => ({ ...s, until: daysBetween(date, s.examDate) }))
      .filter((s) => s.until >= 0);
    const examsToday = upcoming.filter((s) => s.until === 0);
    const examTomorrow = upcoming.some((s) => s.until === 1);

    const base: Omit<PlanDay, 'studyHours' | 'blocks' | 'note'> = {
      date,
      wakeTime: input.wakeTime,
      bedtime,
      sleepHours,
      exams: examsToday.map((s) => s.name),
    };

    if (upcoming.length === 0 || maxStudy === 0) {
      days.push({
        ...base,
        studyHours: 0,
        blocks: [],
        note: upcoming.length === 0 ? 'No exams left to prepare for. Rest and recover.' : 'Study is switched off for this day.',
      });
      continue;
    }

    let loadHours = maxStudy;
    let note = 'Full study day. Take the breaks, and protect your sleep.';
    let pool = upcoming;
    if (examsToday.length > 0) {
      loadHours = Math.min(loadHours, 2);
      pool = examsToday;
      note = 'Exam day: a short, light review only. Eat, move, and arrive rested.';
    } else if (examTomorrow) {
      loadHours = Math.min(loadHours, 6);
      note = 'Exam tomorrow: study is capped at 6 hours so you can sleep well tonight.';
    }

    const totalMin = Math.floor((loadHours * 60) / QUANTUM) * QUANTUM;
    const weights = pool.map((s) => s.difficulty / (s.until + 1));
    const minutes = allocate(totalMin, weights);
    // A subject with under 30 minutes is not worth a block: give that time to the top subject.
    const top = weights.indexOf(Math.max(...weights));
    minutes.forEach((m, i) => {
      if (i !== top && m > 0 && m < MIN_SUBJECT_MINUTES) {
        minutes[top] += m;
        minutes[i] = 0;
      }
    });
    const order = pool
      .map((s, i) => ({ name: s.name, minutes: minutes[i], weight: weights[i] }))
      .filter((item) => item.minutes > 0)
      .sort((a, b) => b.weight - a.weight);

    const chunks: { subject: string; minutes: number }[] = [];
    for (const item of order) {
      for (const len of splitIntoBlocks(item.minutes)) chunks.push({ subject: item.name, minutes: len });
    }

    const blocks: StudyBlock[] = [];
    let cursor = studyStart;
    let placed = 0;
    let trimmed = false;
    chunks.forEach((chunk, i) => {
      if (trimmed) return;
      if (cursor + chunk.minutes > studyLimit) {
        trimmed = true;
        return;
      }
      blocks.push({
        subject: chunk.subject,
        start: formatTime(cursor),
        end: formatTime(cursor + chunk.minutes),
        hours: chunk.minutes / 60,
      });
      placed += chunk.minutes;
      cursor += chunk.minutes + (i === 2 ? LUNCH_BREAK : SHORT_BREAK);
    });
    if (trimmed) note += ' Trimmed to finish 2 hours before bedtime.';

    days.push({ ...base, studyHours: placed / 60, blocks, note });
  }
  return days;
}
