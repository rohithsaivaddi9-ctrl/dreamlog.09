import type { CorrelationResult, CorrelationStrength, Pair, Regression } from './types';

/** Fewer paired days than this and the correlation is too noisy to trust. */
export const MIN_DAYS = 7;
export const MIN_DAYS_NOTICE = 'Needs at least 7 days of logs for statistical confidence';

export function mean(xs: number[]): number {
  return xs.reduce((a, b) => a + b, 0) / xs.length;
}

/** Pearson correlation coefficient. Returns null if it is undefined (n < 2 or no variation). */
export function pearson(xs: number[], ys: number[]): number | null {
  const n = xs.length;
  if (n !== ys.length || n < 2) return null;
  const mx = mean(xs);
  const my = mean(ys);
  let sxy = 0;
  let sxx = 0;
  let syy = 0;
  for (let i = 0; i < n; i++) {
    const dx = xs[i] - mx;
    const dy = ys[i] - my;
    sxy += dx * dy;
    sxx += dx * dx;
    syy += dy * dy;
  }
  if (sxx === 0 || syy === 0) return null;
  const r = sxy / Math.sqrt(sxx * syy);
  return Math.max(-1, Math.min(1, r));
}

/** Ordinary least squares fit y = intercept + slope * x. Null if x has no spread. */
export function linearRegression(xs: number[], ys: number[]): Regression | null {
  const n = xs.length;
  if (n !== ys.length || n < 2) return null;
  const mx = mean(xs);
  const my = mean(ys);
  let sxy = 0;
  let sxx = 0;
  for (let i = 0; i < n; i++) {
    sxy += (xs[i] - mx) * (ys[i] - my);
    sxx += (xs[i] - mx) ** 2;
  }
  if (sxx === 0) return null;
  const slope = sxy / sxx;
  return { slope, intercept: my - slope * mx };
}

export function describeCorrelation(r: number | null): { strength: CorrelationStrength; label: string } {
  if (r === null) return { strength: 'None', label: 'Not enough variation yet' };
  const abs = Math.abs(r);
  if (abs < 0.2) return { strength: 'None', label: 'No Meaningful Correlation' };
  const strength: CorrelationStrength = abs >= 0.7 ? 'Strong' : abs >= 0.4 ? 'Moderate' : 'Weak';
  return { strength, label: `${strength} ${r > 0 ? 'Positive' : 'Negative'} Correlation` };
}

/** Sleep duration vs focus rating: r, a label, the regression line and the small-sample notice. */
export function analyzeCorrelation(xs: number[], ys: number[]): CorrelationResult {
  const n = Math.min(xs.length, ys.length);
  const r = pearson(xs, ys);
  const { strength, label } = describeCorrelation(r);
  return {
    n,
    r,
    rSquared: r === null ? null : r * r,
    label,
    strength,
    sufficient: n >= MIN_DAYS,
    notice: n >= MIN_DAYS ? null : MIN_DAYS_NOTICE,
    regression: linearRegression(xs, ys),
  };
}

export function analyzePairs(pairs: Pair[]): CorrelationResult {
  return analyzeCorrelation(
    pairs.map((p) => p.sleepHours),
    pairs.map((p) => p.focus),
  );
}

/** Newest paired day, and what r would have been without it. */
export function correlationWithChange(pairs: Pair[]): {
  current: CorrelationResult;
  previous: CorrelationResult | null;
  latest: Pair | null;
} {
  const sorted = [...pairs].sort((a, b) => a.date.localeCompare(b.date));
  const current = analyzePairs(sorted);
  if (sorted.length === 0) return { current, previous: null, latest: null };
  const latest = sorted[sorted.length - 1];
  const previous = sorted.length >= 3 ? analyzePairs(sorted.slice(0, -1)) : null;
  return { current, previous, latest };
}

export function formatR(r: number | null): string {
  if (r === null) return '—';
  const v = r.toFixed(2);
  return r > 0 ? `+${v}` : v;
}
