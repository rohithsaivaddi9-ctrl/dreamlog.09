/**
 * Sleep forecasting and anomaly detection.
 *
 * - Holt's double exponential smoothing (level + trend) forecasts the next
 *   nights of sleep, with the smoothing parameters chosen by grid search to
 *   minimise one-step-ahead squared error on the user's own history.
 * - Robust anomaly detection uses the median absolute deviation (MAD), which,
 *   unlike a plain z-score, is not distorted by the very outliers it looks for.
 * - Cumulative sleep debt is projected forward from the forecast.
 */

export interface HoltModel {
  alpha: number;
  beta: number;
  level: number;
  trend: number;
  sse: number;
}

export interface ForecastPoint {
  step: number;
  value: number;
  low: number;
  high: number;
}

export interface Anomaly {
  index: number;
  value: number;
  score: number; // robust z-score
  direction: 'low' | 'high';
}

export function median(xs: number[]): number {
  if (xs.length === 0) return NaN;
  const s = [...xs].sort((a, b) => a - b);
  const m = s.length >> 1;
  return s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2;
}

/** Fits Holt smoothing with fixed parameters; returns final state and SSE of one-step forecasts. */
export function fitHolt(series: number[], alpha: number, beta: number): HoltModel {
  if (series.length < 2) throw new Error('Need at least 2 points');
  let level = series[0];
  let trend = series[1] - series[0];
  let sse = 0;
  for (let i = 1; i < series.length; i++) {
    const pred = level + trend;
    sse += (series[i] - pred) ** 2;
    const prevLevel = level;
    level = alpha * series[i] + (1 - alpha) * (level + trend);
    trend = beta * (level - prevLevel) + (1 - beta) * trend;
  }
  return { alpha, beta, level, trend, sse };
}

/** Grid-searches alpha/beta in 0.05 steps for the lowest SSE. */
export function autoHolt(series: number[]): HoltModel {
  let best: HoltModel | null = null;
  for (let a = 0.05; a <= 0.951; a += 0.05) {
    for (let b = 0.05; b <= 0.951; b += 0.05) {
      const m = fitHolt(series, Math.round(a * 100) / 100, Math.round(b * 100) / 100);
      if (!best || m.sse < best.sse) best = m;
    }
  }
  return best!;
}

/** Forecasts `horizon` steps with an approximate 80% band that widens with distance. */
export function forecast(series: number[], horizon = 3, clamp: [number, number] = [0, 14]): ForecastPoint[] {
  if (series.length < 4) return [];
  const m = autoHolt(series);
  const sigma = Math.sqrt(m.sse / Math.max(1, series.length - 2));
  const z = 1.2816;
  const lim = (x: number) => Math.min(clamp[1], Math.max(clamp[0], x));
  const out: ForecastPoint[] = [];
  for (let h = 1; h <= horizon; h++) {
    // Damp the trend so a short streak cannot predict 0 h or 14 h sleep.
    const value = m.level + m.trend * h * Math.pow(0.8, h - 1);
    const band = z * sigma * Math.sqrt(h);
    out.push({ step: h, value: round(lim(value)), low: round(lim(value - band)), high: round(lim(value + band)) });
  }
  return out;
}

/** Flags values whose robust z-score (0.6745 * |x - median| / MAD) exceeds `threshold`. */
export function detectAnomalies(series: number[], threshold = 3.5): Anomaly[] {
  if (series.length < 5) return [];
  const med = median(series);
  const mad = median(series.map((x) => Math.abs(x - med)));
  if (mad === 0) return [];
  const out: Anomaly[] = [];
  series.forEach((x, i) => {
    const score = (0.6745 * (x - med)) / mad;
    if (Math.abs(score) > threshold) out.push({ index: i, value: x, score: round(score), direction: score < 0 ? 'low' : 'high' });
  });
  return out;
}

/** Projects cumulative debt (hours) over the forecast horizon from today's debt. */
export function projectDebt(currentDebt: number, points: ForecastPoint[], target: number): number[] {
  let debt = currentDebt;
  return points.map((p) => {
    debt = Math.max(0, debt + (target - p.value));
    return round(debt);
  });
}

function round(x: number): number {
  return Math.round(x * 100) / 100;
}
