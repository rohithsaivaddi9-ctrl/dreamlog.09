import { addDays } from './dates';
import type { SleepDebt, SleepDebtNight, SleepLog } from './types';

export const DEFAULT_SLEEP_TARGET = 8;

const round1 = (v: number) => Math.round(v * 10) / 10;

/**
 * Sleep debt over the last `windowDays` nights (ending at the most recent logged night)
 * against a nightly target. Shortfall only counts nights that fell below the target;
 * nights with nothing logged are shown as gaps and not counted either way.
 */
export function computeSleepDebt(
  logs: SleepLog[],
  target: number = DEFAULT_SLEEP_TARGET,
  windowDays = 7,
): SleepDebt {
  if (logs.length === 0) {
    return {
      target,
      windowDays,
      endDate: null,
      nights: [],
      nightsLogged: 0,
      shortfall: 0,
      surplus: 0,
      net: 0,
      level: 'unknown',
    };
  }
  const byDate = new Map(logs.map((l) => [l.date, l.durationHours]));
  const endDate = logs.reduce((max, l) => (l.date > max ? l.date : max), logs[0].date);
  const nights: SleepDebtNight[] = [];
  let shortfall = 0;
  let surplus = 0;
  let nightsLogged = 0;
  for (let i = windowDays - 1; i >= 0; i--) {
    const date = addDays(endDate, -i);
    const hours = byDate.get(date) ?? null;
    let deficit = 0;
    if (hours !== null) {
      nightsLogged++;
      if (hours < target) {
        deficit = target - hours;
        shortfall += deficit;
      } else {
        surplus += hours - target;
      }
    }
    nights.push({ date, hours, deficit: round1(deficit) });
  }
  shortfall = round1(shortfall);
  surplus = round1(surplus);
  const level: SleepDebt['level'] = shortfall <= 1 ? 'on-track' : shortfall <= 5 ? 'mild' : 'significant';
  return {
    target,
    windowDays,
    endDate,
    nights,
    nightsLogged,
    shortfall,
    surplus,
    net: round1(surplus - shortfall),
    level,
  };
}
