import { isValidISODate } from './dates';
import { parseTime, sleepDurationHours } from './time';
import type { CaffeineInput, SleepInput, StudyInput, Validated } from './types';

type Body = Record<string, unknown>;

function asBody(input: unknown): Body {
  return input !== null && typeof input === 'object' ? (input as Body) : {};
}

function isInt(v: unknown, min: number, max: number): v is number {
  return typeof v === 'number' && Number.isInteger(v) && v >= min && v <= max;
}

export function validateSleepInput(input: unknown): Validated<SleepInput> {
  const b = asBody(input);
  const errors: string[] = [];
  if (!isValidISODate(b.date)) errors.push('date must be a valid YYYY-MM-DD date');
  if (parseTime(b.bedtime) === null) errors.push('bedtime must be a time like 23:30');
  if (parseTime(b.wakeTime) === null) errors.push('wakeTime must be a time like 07:30');
  if (!isInt(b.quality, 1, 5)) errors.push('quality must be a whole number from 1 to 5');
  if (errors.length > 0) return { ok: false, errors };

  const durationHours = sleepDurationHours(b.bedtime as string, b.wakeTime as string);
  if (durationHours <= 0) return { ok: false, errors: ['bedtime and wake time must be different'] };
  if (durationHours > 16) return { ok: false, errors: ['sleep longer than 16 hours looks like a typo, check the times'] };
  return {
    ok: true,
    value: {
      date: b.date as string,
      bedtime: b.bedtime as string,
      wakeTime: b.wakeTime as string,
      quality: b.quality as number,
      durationHours,
    },
  };
}

export function validateStudyInput(input: unknown): Validated<StudyInput> {
  const b = asBody(input);
  const errors: string[] = [];
  if (!isValidISODate(b.date)) errors.push('date must be a valid YYYY-MM-DD date');

  const hours = b.hoursStudied;
  if (typeof hours !== 'number' || !Number.isFinite(hours) || hours < 0 || hours > 16) {
    errors.push('hoursStudied must be a number from 0 to 16');
  }

  let subjects: string[] = [];
  if (!Array.isArray(b.subjects)) {
    errors.push('subjects must be a list');
  } else {
    subjects = b.subjects
      .filter((s): s is string => typeof s === 'string')
      .map((s) => s.trim())
      .filter((s) => s.length > 0);
    if (subjects.length > 10) errors.push('at most 10 subjects per day');
    if (subjects.some((s) => s.length > 40)) errors.push('subject names must be 40 characters or fewer');
    if (typeof hours === 'number' && hours > 0 && subjects.length === 0) errors.push('add at least one subject you studied');
  }

  if (!isInt(b.focus, 1, 5)) errors.push('focus must be a whole number from 1 to 5');

  let score: number | null = null;
  if (b.score !== null && b.score !== undefined && b.score !== '') {
    if (typeof b.score !== 'number' || !Number.isFinite(b.score) || b.score < 0 || b.score > 100) {
      errors.push('score must be a number from 0 to 100');
    } else {
      score = b.score;
    }
  }

  if (errors.length > 0) return { ok: false, errors };
  return {
    ok: true,
    value: {
      date: b.date as string,
      hoursStudied: hours as number,
      subjects,
      focus: b.focus as number,
      score,
    },
  };
}

export function validateCaffeineInput(input: unknown): Validated<CaffeineInput> {
  const b = asBody(input);
  const errors: string[] = [];
  if (!isValidISODate(b.date)) errors.push('date must be a valid YYYY-MM-DD date');
  if (parseTime(b.time) === null) errors.push('time must be a time like 14:30');
  const drink = typeof b.drink === 'string' ? b.drink.trim() : '';
  if (drink.length === 0 || drink.length > 40) errors.push('drink must be 1 to 40 characters');
  if (typeof b.mg !== 'number' || !Number.isFinite(b.mg) || b.mg < 1 || b.mg > 1000) {
    errors.push('mg must be a number from 1 to 1000');
  }
  if (errors.length > 0) return { ok: false, errors };
  return {
    ok: true,
    value: { date: b.date as string, time: b.time as string, drink, mg: b.mg as number },
  };
}

export function validateSleepTarget(input: unknown): Validated<number> {
  const v = asBody(input).sleepTarget;
  if (typeof v !== 'number' || !Number.isFinite(v) || v < 4 || v > 12) {
    return { ok: false, errors: ['sleepTarget must be a number from 4 to 12'] };
  }
  return { ok: true, value: Math.round(v * 4) / 4 };
}
