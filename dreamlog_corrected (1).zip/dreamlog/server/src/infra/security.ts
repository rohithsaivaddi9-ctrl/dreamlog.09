import type { NextFunction, Request, Response } from 'express';
import { randomUUID } from 'node:crypto';
import { RateLimitError } from './errors';

/** Basic hardening headers (what helmet would set, without the dependency). */
export function securityHeaders(_req: Request, res: Response, next: NextFunction): void {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'",
  );
  res.removeHeader('X-Powered-By');
  next();
}

/** Tags each request with an id so log lines and error responses can be matched. */
export function requestId(req: Request, res: Response, next: NextFunction): void {
  const incoming = req.header('x-request-id');
  const id = incoming && /^[\w-]{1,64}$/.test(incoming) ? incoming : randomUUID();
  res.locals.requestId = id;
  res.setHeader('X-Request-Id', id);
  next();
}

/** Token-bucket rate limiter per client IP. */
export function rateLimiter(opts: { capacity?: number; refillPerSec?: number; now?: () => number } = {}) {
  const capacity = opts.capacity ?? 120;
  const refill = opts.refillPerSec ?? 20;
  const now = opts.now ?? Date.now;
  const buckets = new Map<string, { tokens: number; last: number }>();
  return (req: Request, res: Response, next: NextFunction): void => {
    const key = req.ip ?? 'unknown';
    const t = now();
    const b = buckets.get(key) ?? { tokens: capacity, last: t };
    b.tokens = Math.min(capacity, b.tokens + ((t - b.last) / 1000) * refill);
    b.last = t;
    if (b.tokens < 1) {
      buckets.set(key, b);
      return next(new RateLimitError(Math.ceil((1 - b.tokens) / refill)));
    }
    b.tokens -= 1;
    buckets.set(key, b);
    if (buckets.size > 10_000) buckets.clear(); // memory guard
    res.setHeader('X-RateLimit-Remaining', String(Math.floor(b.tokens)));
    next();
  };
}
