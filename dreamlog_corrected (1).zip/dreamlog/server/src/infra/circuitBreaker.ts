import { ServiceUnavailableError } from './errors';

export type BreakerState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface BreakerOptions {
  failureThreshold?: number; // consecutive failures before opening
  cooldownMs?: number; // how long to stay open before a trial call
  now?: () => number; // injectable clock for tests
  isFailure?: (err: unknown) => boolean; // only infrastructure errors trip the breaker
}

/**
 * Classic three-state circuit breaker. When the database keeps failing we stop
 * hammering it and fail fast with 503 + Retry-After, then let one trial call
 * through after the cooldown to see if it has recovered.
 */
export class CircuitBreaker {
  private state: BreakerState = 'CLOSED';
  private failures = 0;
  private openedAt = 0;
  private readonly threshold: number;
  private readonly cooldownMs: number;
  private readonly now: () => number;
  private readonly isFailure: (err: unknown) => boolean;

  constructor(readonly name: string, opts: BreakerOptions = {}) {
    this.threshold = opts.failureThreshold ?? 5;
    this.cooldownMs = opts.cooldownMs ?? 10_000;
    this.now = opts.now ?? Date.now;
    this.isFailure = opts.isFailure ?? (() => true);
  }

  getState(): BreakerState {
    if (this.state === 'OPEN' && this.now() - this.openedAt >= this.cooldownMs) this.state = 'HALF_OPEN';
    return this.state;
  }

  exec<T>(fn: () => T): T {
    if (this.getState() === 'OPEN') {
      const waitMs = this.cooldownMs - (this.now() - this.openedAt);
      throw new ServiceUnavailableError(`${this.name} temporarily unavailable`, Math.max(1, Math.ceil(waitMs / 1000)));
    }
    try {
      const out = fn();
      this.failures = 0;
      this.state = 'CLOSED';
      return out;
    } catch (err) {
      if (this.isFailure(err)) {
        this.failures++;
        if (this.state === 'HALF_OPEN' || this.failures >= this.threshold) {
          this.state = 'OPEN';
          this.openedAt = this.now();
        }
      }
      throw err;
    }
  }

  stats() {
    return { name: this.name, state: this.getState(), consecutiveFailures: this.failures };
  }
}
