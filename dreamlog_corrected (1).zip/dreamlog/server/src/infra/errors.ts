/**
 * Typed error hierarchy so each failure mode gets its own HTTP status and
 * recovery path, instead of one generic 500 for everything.
 */
export class AppError extends Error {
  constructor(
    message: string,
    readonly status: number,
    readonly code: string,
    readonly details?: unknown,
    readonly retryable = false,
  ) {
    super(message);
    this.name = new.target.name;
  }
}
export class ValidationError extends AppError {
  constructor(errors: string[]) {
    super('Invalid input', 400, 'VALIDATION_FAILED', errors);
  }
}
export class NotFoundError extends AppError {
  constructor(what: string) {
    super(`${what} not found`, 404, 'NOT_FOUND');
  }
}
export class ConflictError extends AppError {
  constructor(message: string) {
    super(message, 409, 'CONFLICT');
  }
}
export class ServiceUnavailableError extends AppError {
  constructor(message: string, readonly retryAfterSec = 5) {
    super(message, 503, 'SERVICE_UNAVAILABLE', undefined, true);
  }
}
export class RateLimitError extends AppError {
  constructor(readonly retryAfterSec: number) {
    super('Too many requests, slow down', 429, 'RATE_LIMITED', undefined, true);
  }
}

/** Maps low-level SQLite / body-parser errors to a typed AppError. */
export function toAppError(err: unknown): AppError {
  if (err instanceof AppError) return err;
  const e = err as { message?: string; code?: string; type?: string; status?: number } | undefined;
  const msg = String(e?.message ?? '');
  if (e?.type === 'entity.parse.failed') return new AppError('Malformed JSON body', 400, 'BAD_JSON');
  if (e?.type === 'entity.too.large') return new AppError('Request body too large', 413, 'PAYLOAD_TOO_LARGE');
  if (/SQLITE_BUSY|SQLITE_LOCKED|database is locked/i.test(msg)) {
    return new ServiceUnavailableError('Database is busy, please retry', 1);
  }
  if (/CHECK constraint failed/i.test(msg)) return new AppError('Value out of allowed range', 400, 'CONSTRAINT_VIOLATION');
  if (/UNIQUE constraint failed/i.test(msg)) return new ConflictError('Record already exists');
  return new AppError('Something went wrong on the server', 500, 'INTERNAL');
}
