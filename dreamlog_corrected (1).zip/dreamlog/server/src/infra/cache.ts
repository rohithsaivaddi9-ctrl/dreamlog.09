/**
 * Small LRU cache with TTL and a global "version" counter. Every write to the
 * database bumps the version, so cached analytics are never stale, while
 * repeated dashboard loads skip the heavy statistics work entirely.
 */
export class LruCache<V> {
  private map = new Map<string, { value: V; expires: number; version: number }>();
  private version = 0;
  hits = 0;
  misses = 0;

  constructor(
    private readonly maxEntries = 100,
    private readonly ttlMs = 60_000,
    private readonly now: () => number = Date.now,
  ) {}

  invalidate(): void {
    this.version++;
    this.map.clear();
  }

  get(key: string): V | undefined {
    const e = this.map.get(key);
    if (!e || e.expires < this.now() || e.version !== this.version) {
      if (e) this.map.delete(key);
      this.misses++;
      return undefined;
    }
    this.map.delete(key); // refresh LRU order
    this.map.set(key, e);
    this.hits++;
    return e.value;
  }

  set(key: string, value: V): void {
    if (this.map.has(key)) this.map.delete(key);
    else if (this.map.size >= this.maxEntries) this.map.delete(this.map.keys().next().value as string);
    this.map.set(key, { value, expires: this.now() + this.ttlMs, version: this.version });
  }

  getOrCompute(key: string, compute: () => V): V {
    const hit = this.get(key);
    if (hit !== undefined) return hit;
    const v = compute();
    this.set(key, v);
    return v;
  }

  stats() {
    const total = this.hits + this.misses;
    return { size: this.map.size, hits: this.hits, misses: this.misses, hitRate: total ? this.hits / total : 0 };
  }
}
