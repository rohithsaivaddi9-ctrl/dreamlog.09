import type { StudyLog } from '../../shared/types';

// 21 days of student logs (5-9 h sleep, 2-8 h study, focus 1-5) that show a positive
// sleep/focus correlation: r = +0.77 for these 21 days, rising to about +0.78 after
// the demo night from the project brief is logged. daysAgo 1 = yesterday.
export interface SeedDay {
  daysAgo: number;
  bedtime: string;
  wakeTime: string;
  quality: number;
  hoursStudied: number;
  subjects: string[];
  focus: number;
  score: StudyLog['score'];
}

export const SEED_DAYS: SeedDay[] = [
  { daysAgo: 21, bedtime: '02:15', wakeTime: '08:15', quality: 2, hoursStudied: 7, subjects: ['Physics'], focus: 2, score: 60 },
  { daysAgo: 20, bedtime: '01:30', wakeTime: '08:00', quality: 2, hoursStudied: 7, subjects: ['Calculus'], focus: 3, score: null },
  { daysAgo: 19, bedtime: '02:00', wakeTime: '07:30', quality: 1, hoursStudied: 7.5, subjects: ['Databases'], focus: 1, score: null },
  { daysAgo: 18, bedtime: '00:45', wakeTime: '07:00', quality: 3, hoursStudied: 6.5, subjects: ['Operating Systems','Calculus'], focus: 2, score: 61 },
  { daysAgo: 17, bedtime: '01:15', wakeTime: '08:30', quality: 4, hoursStudied: 6.5, subjects: ['Operating Systems'], focus: 3, score: 61 },
  { daysAgo: 16, bedtime: '02:30', wakeTime: '08:30', quality: 2, hoursStudied: 8, subjects: ['Physics','Calculus'], focus: 3, score: 74 },
  { daysAgo: 15, bedtime: '22:45', wakeTime: '06:30', quality: 2, hoursStudied: 5, subjects: ['Physics'], focus: 2, score: null },
  { daysAgo: 14, bedtime: '03:45', wakeTime: '09:00', quality: 1, hoursStudied: 8, subjects: ['Literature'], focus: 1, score: null },
  { daysAgo: 13, bedtime: '00:30', wakeTime: '07:30', quality: 3, hoursStudied: 6.5, subjects: ['Calculus'], focus: 2, score: null },
  { daysAgo: 12, bedtime: '03:15', wakeTime: '08:15', quality: 1, hoursStudied: 6, subjects: ['Databases','Literature'], focus: 2, score: 59 },
  { daysAgo: 11, bedtime: '01:15', wakeTime: '06:45', quality: 2, hoursStudied: 6.5, subjects: ['Literature'], focus: 2, score: null },
  { daysAgo: 10, bedtime: '01:15', wakeTime: '08:00', quality: 2, hoursStudied: 7.5, subjects: ['Operating Systems'], focus: 2, score: null },
  { daysAgo: 9, bedtime: '00:15', wakeTime: '09:00', quality: 4, hoursStudied: 7.5, subjects: ['Literature','Algorithms'], focus: 5, score: null },
  { daysAgo: 8, bedtime: '22:30', wakeTime: '06:45', quality: 3, hoursStudied: 6, subjects: ['Algorithms'], focus: 3, score: null },
  { daysAgo: 7, bedtime: '00:45', wakeTime: '07:00', quality: 1, hoursStudied: 8, subjects: ['Calculus'], focus: 3, score: 68 },
  { daysAgo: 6, bedtime: '23:15', wakeTime: '06:45', quality: 2, hoursStudied: 5, subjects: ['Databases'], focus: 4, score: null },
  { daysAgo: 5, bedtime: '23:30', wakeTime: '08:00', quality: 3, hoursStudied: 5.5, subjects: ['Calculus','Operating Systems'], focus: 5, score: 78 },
  { daysAgo: 4, bedtime: '01:00', wakeTime: '09:00', quality: 3, hoursStudied: 5.5, subjects: ['Databases'], focus: 3, score: 73 },
  { daysAgo: 3, bedtime: '23:15', wakeTime: '07:30', quality: 3, hoursStudied: 5.5, subjects: ['Databases'], focus: 4, score: 70 },
  { daysAgo: 2, bedtime: '02:30', wakeTime: '08:30', quality: 1, hoursStudied: 6.5, subjects: ['Operating Systems'], focus: 2, score: 53 },
  { daysAgo: 1, bedtime: '01:45', wakeTime: '08:15', quality: 2, hoursStudied: 7.5, subjects: ['Algorithms','Databases'], focus: 3, score: null },
];
