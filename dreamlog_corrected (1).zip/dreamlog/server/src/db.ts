import { DatabaseSync, type StatementSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

export type Db = DatabaseSync;

const SCHEMA = `
CREATE TABLE IF NOT EXISTS sleep_logs (
  date           TEXT PRIMARY KEY,           -- morning you woke up, YYYY-MM-DD
  bedtime        TEXT NOT NULL,              -- HH:MM
  wake_time      TEXT NOT NULL,              -- HH:MM
  duration_hours REAL NOT NULL,
  quality        INTEGER NOT NULL CHECK (quality BETWEEN 1 AND 5)
);

CREATE TABLE IF NOT EXISTS study_logs (
  date          TEXT PRIMARY KEY,
  hours_studied REAL NOT NULL CHECK (hours_studied >= 0),
  subjects      TEXT NOT NULL,               -- JSON array of strings
  focus         INTEGER NOT NULL CHECK (focus BETWEEN 1 AND 5),
  score         REAL                         -- optional quiz / exam score
);

CREATE TABLE IF NOT EXISTS caffeine_logs (
  id    INTEGER PRIMARY KEY AUTOINCREMENT,
  date  TEXT NOT NULL,
  time  TEXT NOT NULL,
  drink TEXT NOT NULL,
  mg    REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- One row per day the correlation was recalculated (history of r over time).
CREATE TABLE IF NOT EXISTS correlation_metrics (
  computed_on TEXT PRIMARY KEY,
  n           INTEGER NOT NULL,
  r           REAL,
  slope       REAL,
  intercept   REAL,
  label       TEXT NOT NULL
);

-- Indexes for the hot query paths (caffeine by day, time-ordered scans).
CREATE INDEX IF NOT EXISTS idx_caffeine_date_time ON caffeine_logs (date, time, id);
CREATE INDEX IF NOT EXISTS idx_metrics_computed   ON correlation_metrics (computed_on);
`;

/**
 * Prepared-statement cache. node:sqlite is an in-process, synchronous engine,
 * so one shared connection is the correct "pool" (multiple connections would
 * only fight over the write lock). What a pool really saves - re-parsing and
 * re-planning SQL on every request - is achieved by compiling each statement
 * once per connection and reusing it.
 */
const stmtCache = new WeakMap<Db, Map<string, StatementSync>>();
export function stmt(db: Db, sql: string): StatementSync {
  let m = stmtCache.get(db);
  if (!m) stmtCache.set(db, (m = new Map()));
  let s = m.get(sql);
  if (!s) m.set(sql, (s = db.prepare(sql)));
  return s;
}
export function preparedStatementCount(db: Db): number {
  return stmtCache.get(db)?.size ?? 0;
}

/** Runs `fn` inside a transaction; rolls back on any error. */
export function transaction<T>(db: Db, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const out = fn();
    db.exec('COMMIT');
    return out;
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
}

/** Opens (and creates, if needed) the SQLite database. Use ':memory:' for tests. */
export function openDb(file: string): Db {
  if (file !== ':memory:') fs.mkdirSync(path.dirname(file), { recursive: true });
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode = WAL;'); // readers never block the writer
  db.exec('PRAGMA synchronous = NORMAL;'); // safe with WAL, far fewer fsyncs
  db.exec('PRAGMA busy_timeout = 3000;'); // wait for a lock instead of failing at once
  db.exec('PRAGMA cache_size = -8000;'); // ~8 MB page cache
  db.exec('PRAGMA temp_store = MEMORY;');
  db.exec(SCHEMA);
  return db;
}
