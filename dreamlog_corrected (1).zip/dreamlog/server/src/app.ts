import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { preparedStatementCount, type Db } from './db';
import { todayISO, isValidISODate } from '../../shared/dates';
import { parseTime } from '../../shared/time';
import { validateCaffeineInput, validateSleepInput, validateSleepTarget, validateStudyInput } from '../../shared/validation';
import {
  addCaffeine,
  deleteCaffeine,
  deleteSleep,
  deleteStudy,
  getSleepTarget,
  listCaffeine,
  listSleep,
  listStudy,
  setSleepTarget,
  upsertSleep,
  upsertStudy,
} from './repo';
import { getAnalytics, getCaffeineStatus, getForecast, getReport } from './services';
import { seedDatabase } from './seed';
import { AppError, NotFoundError, RateLimitError, ServiceUnavailableError, ValidationError, toAppError } from './infra/errors';
import { CircuitBreaker } from './infra/circuitBreaker';
import { LruCache } from './infra/cache';
import { rateLimiter, requestId, securityHeaders } from './infra/security';

type Handler = (req: Request, res: Response) => unknown | Promise<unknown>;

export interface AppOptions {
  clientDir?: string;
  rateLimit?: { capacity?: number; refillPerSec?: number };
  breaker?: { failureThreshold?: number; cooldownMs?: number };
  cacheTtlMs?: number;
}

/** Wraps sync AND async handlers so every error reaches the typed error middleware. */
const route =
  (fn: Handler) =>
  (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve()
      .then(() => fn(req, res))
      .catch(next);
  };

function validated<T>(v: { ok: true; value: T } | { ok: false; errors: string[] }): T {
  if (!v.ok) throw new ValidationError(v.errors);
  return v.value;
}

function todayParam(v: unknown): string {
  return typeof v === 'string' && isValidISODate(v) ? v : todayISO();
}

export function createApp(db: Db, opts: AppOptions | string = {}): express.Express {
  const o: AppOptions = typeof opts === 'string' ? { clientDir: opts } : opts;
  const app = express();
  app.disable('x-powered-by');

  // Only infrastructure faults (not bad input / not-found) count towards opening the breaker.
  const breaker = new CircuitBreaker('database', {
    failureThreshold: o.breaker?.failureThreshold ?? 5,
    cooldownMs: o.breaker?.cooldownMs ?? 10_000,
    isFailure: (err) => !(err instanceof AppError) || err.status >= 500,
  });
  const cache = new LruCache<unknown>(50, o.cacheTtlMs ?? 60_000);

  /** Every database call goes through the breaker. */
  const withDb = <T>(fn: () => T): T => breaker.exec(fn);
  /** Reads that are expensive to compute are cached until the next write. */
  const cached = <T>(key: string, fn: () => T): T => cache.getOrCompute(key, () => withDb(fn)) as T;
  /** Writes invalidate the analytics cache. */
  const write = <T>(fn: () => T): T => {
    const out = withDb(fn);
    cache.invalidate();
    return out;
  };

  app.use(requestId);
  app.use(securityHeaders);
  app.use('/api', rateLimiter(o.rateLimit));
  app.use(express.json({ limit: '20kb' }));

  // ---- health ----
  app.get('/api/health', route((_req, res) => {
    const state = breaker.getState();
    res.status(state === 'OPEN' ? 503 : 200).json({
      status: state === 'OPEN' ? 'degraded' : 'ok',
      breaker: breaker.stats(),
      cache: cache.stats(),
      preparedStatements: preparedStatementCount(db),
      uptimeSec: Math.round(process.uptime()),
    });
  }));

  // ---- sleep ----
  app.get('/api/sleep', route((_req, res) => res.json(cached('sleep', () => listSleep(db)))));
  app.post('/api/sleep', route((req, res) => {
    const v = validated(validateSleepInput(req.body));
    res.status(201).json(write(() => upsertSleep(db, v)));
  }));
  app.delete('/api/sleep/:date', route((req, res) => {
    if (!isValidISODate(req.params.date) || !write(() => deleteSleep(db, req.params.date))) throw new NotFoundError('Sleep log');
    res.json({ deleted: true });
  }));

  // ---- study ----
  app.get('/api/study', route((_req, res) => res.json(cached('study', () => listStudy(db)))));
  app.post('/api/study', route((req, res) => {
    const v = validated(validateStudyInput(req.body));
    res.status(201).json(write(() => upsertStudy(db, v)));
  }));
  app.delete('/api/study/:date', route((req, res) => {
    if (!isValidISODate(req.params.date) || !write(() => deleteStudy(db, req.params.date))) throw new NotFoundError('Study log');
    res.json({ deleted: true });
  }));

  // ---- caffeine ----
  app.get('/api/caffeine', route((req, res) => {
    const date = typeof req.query.date === 'string' ? req.query.date : undefined;
    if (date !== undefined && !isValidISODate(date)) throw new ValidationError(['date must be YYYY-MM-DD']);
    res.json(cached(`caffeine:${date ?? 'all'}`, () => listCaffeine(db, date)));
  }));
  app.post('/api/caffeine', route((req, res) => {
    const v = validated(validateCaffeineInput(req.body));
    res.status(201).json(write(() => addCaffeine(db, v)));
  }));
  app.delete('/api/caffeine/:id', route((req, res) => {
    const id = Number(req.params.id);
    if (!Number.isInteger(id) || !write(() => deleteCaffeine(db, id))) throw new NotFoundError('Caffeine entry');
    res.json({ deleted: true });
  }));
  app.get('/api/caffeine/status', route((req, res) => {
    const date = typeof req.query.date === 'string' ? req.query.date : todayISO();
    const bedtime = typeof req.query.bedtime === 'string' ? req.query.bedtime : '23:30';
    if (!isValidISODate(date) || parseTime(bedtime) === null) {
      throw new ValidationError(['date must be YYYY-MM-DD and bedtime HH:MM']);
    }
    res.json(cached(`caffeine-status:${date}:${bedtime}`, () => getCaffeineStatus(db, date, bedtime)));
  }));

  // ---- analytics, forecast, settings, report ----
  app.get('/api/analytics', route((req, res) => {
    const today = todayParam(req.query.today);
    res.json(cached(`analytics:${today}`, () => getAnalytics(db, today)));
  }));
  app.get('/api/forecast', route((req, res) => {
    const today = todayParam(req.query.today);
    res.json(cached(`forecast:${today}`, () => getForecast(db, today)));
  }));
  app.get('/api/report', route((req, res) => {
    const today = todayParam(req.query.today);
    res.json(cached(`report:${today}`, () => getReport(db, today)));
  }));
  app.get('/api/settings', route((_req, res) => res.json({ sleepTarget: cached('target', () => getSleepTarget(db)) })));
  app.put('/api/settings', route((req, res) => {
    const v = validated(validateSleepTarget(req.body));
    write(() => setSleepTarget(db, v));
    res.json({ sleepTarget: v });
  }));

  /** Wipes all logs and reloads the 21-day demo dataset ending yesterday. */
  app.post('/api/demo/reset', route((req, res) => {
    const today = todayParam(req.body?.today);
    write(() => seedDatabase(db, today, true));
    res.json({ ok: true });
  }));

  app.use('/api', (_req, _res, next) => next(new NotFoundError('Endpoint')));

  // ---- built client (after `npm run build`) ----
  if (o.clientDir && fs.existsSync(path.join(o.clientDir, 'index.html'))) {
    const dir = o.clientDir;
    app.use(express.static(dir, { maxAge: '1h' }));
    app.get('*', (_req, res) => void res.sendFile(path.join(dir, 'index.html')));
  }

  // Typed error handler: each failure mode gets its own status, code and recovery hint.
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    const e = toAppError(err);
    if (e.status >= 500) console.error(`[${res.locals.requestId}]`, err);
    if (e instanceof ServiceUnavailableError || e instanceof RateLimitError) {
      res.setHeader('Retry-After', String(e.retryAfterSec));
    }
    res.status(e.status).json({
      error: e.message,
      code: e.code,
      retryable: e.retryable,
      requestId: res.locals.requestId,
      ...(Array.isArray(e.details) ? { errors: e.details } : {}),
    });
  });

  return app;
}
