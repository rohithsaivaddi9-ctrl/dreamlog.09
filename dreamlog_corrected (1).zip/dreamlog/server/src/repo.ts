import { stmt, type Db } from './db';
import type {
  CaffeineInput,
  CaffeineLog,
  CorrelationResult,
  SleepInput,
  SleepLog,
  StudyInput,
  StudyLog,
} from '../../shared/types';
import { DEFAULT_SLEEP_TARGET } from '../../shared/debt';

interface SleepRow {
  date: string;
  bedtime: string;
  wake_time: string;
  duration_hours: number;
  quality: number;
}
interface StudyRow {
  date: string;
  hours_studied: number;
  subjects: string;
  focus: number;
  score: number | null;
}
interface CaffeineRow {
  id: number;
  date: string;
  time: string;
  drink: string;
  mg: number;
}

// ---- sleep ----

export function listSleep(db: Db): SleepLog[] {
  const rows = stmt(db, 'SELECT * FROM sleep_logs ORDER BY date ASC').all() as unknown as SleepRow[];
  return rows.map((r) => ({
    date: r.date,
    bedtime: r.bedtime,
    wakeTime: r.wake_time,
    durationHours: r.duration_hours,
    quality: r.quality,
  }));
}

export function upsertSleep(db: Db, v: SleepInput): SleepLog {
  stmt(db, 
    `INSERT INTO sleep_logs (date, bedtime, wake_time, duration_hours, quality)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(date) DO UPDATE SET
       bedtime = excluded.bedtime,
       wake_time = excluded.wake_time,
       duration_hours = excluded.duration_hours,
       quality = excluded.quality`,
  ).run(v.date, v.bedtime, v.wakeTime, v.durationHours, v.quality);
  return { date: v.date, bedtime: v.bedtime, wakeTime: v.wakeTime, durationHours: v.durationHours, quality: v.quality };
}

export function deleteSleep(db: Db, date: string): boolean {
  return Number(stmt(db, 'DELETE FROM sleep_logs WHERE date = ?').run(date).changes) > 0;
}

// ---- study ----

export function listStudy(db: Db): StudyLog[] {
  const rows = stmt(db, 'SELECT * FROM study_logs ORDER BY date ASC').all() as unknown as StudyRow[];
  return rows.map((r) => ({
    date: r.date,
    hoursStudied: r.hours_studied,
    subjects: JSON.parse(r.subjects) as string[],
    focus: r.focus,
    score: r.score,
  }));
}

export function upsertStudy(db: Db, v: StudyInput): StudyLog {
  stmt(db, 
    `INSERT INTO study_logs (date, hours_studied, subjects, focus, score)
     VALUES (?, ?, ?, ?, ?)
     ON CONFLICT(date) DO UPDATE SET
       hours_studied = excluded.hours_studied,
       subjects = excluded.subjects,
       focus = excluded.focus,
       score = excluded.score`,
  ).run(v.date, v.hoursStudied, JSON.stringify(v.subjects), v.focus, v.score);
  return { date: v.date, hoursStudied: v.hoursStudied, subjects: v.subjects, focus: v.focus, score: v.score };
}

export function deleteStudy(db: Db, date: string): boolean {
  return Number(stmt(db, 'DELETE FROM study_logs WHERE date = ?').run(date).changes) > 0;
}

// ---- caffeine ----

export function listCaffeine(db: Db, date?: string): CaffeineLog[] {
  const rows = (
    date
      ? stmt(db, 'SELECT * FROM caffeine_logs WHERE date = ? ORDER BY time ASC, id ASC').all(date)
      : stmt(db, 'SELECT * FROM caffeine_logs ORDER BY date ASC, time ASC, id ASC').all()
  ) as unknown as CaffeineRow[];
  return rows.map((r) => ({ id: Number(r.id), date: r.date, time: r.time, drink: r.drink, mg: r.mg }));
}

export function addCaffeine(db: Db, v: CaffeineInput): CaffeineLog {
  const res = stmt(db, 'INSERT INTO caffeine_logs (date, time, drink, mg) VALUES (?, ?, ?, ?)').run(v.date, v.time, v.drink, v.mg);
  return { id: Number(res.lastInsertRowid), ...v };
}

export function deleteCaffeine(db: Db, id: number): boolean {
  return Number(stmt(db, 'DELETE FROM caffeine_logs WHERE id = ?').run(id).changes) > 0;
}

// ---- settings ----

export function getSleepTarget(db: Db): number {
  const row = stmt(db, "SELECT value FROM settings WHERE key = 'sleep_target'").get() as { value: string } | undefined;
  const n = row ? Number(row.value) : NaN;
  return Number.isFinite(n) ? n : DEFAULT_SLEEP_TARGET;
}

export function setSleepTarget(db: Db, hours: number): void {
  stmt(db, 
    `INSERT INTO settings (key, value) VALUES ('sleep_target', ?)
     ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
  ).run(String(hours));
}

// ---- correlation metrics ----

export function saveCorrelationMetrics(db: Db, computedOn: string, c: CorrelationResult): void {
  stmt(db, 
    `INSERT INTO correlation_metrics (computed_on, n, r, slope, intercept, label)
     VALUES (?, ?, ?, ?, ?, ?)
     ON CONFLICT(computed_on) DO UPDATE SET
       n = excluded.n, r = excluded.r, slope = excluded.slope,
       intercept = excluded.intercept, label = excluded.label`,
  ).run(computedOn, c.n, c.r, c.regression?.slope ?? null, c.regression?.intercept ?? null, c.label);
}

// ---- housekeeping ----

export function clearLogs(db: Db): void {
  db.exec('DELETE FROM sleep_logs; DELETE FROM study_logs; DELETE FROM caffeine_logs; DELETE FROM correlation_metrics;');
}

export function countSleep(db: Db): number {
  const row = stmt(db, 'SELECT COUNT(*) AS c FROM sleep_logs').get() as { c: number | bigint };
  return Number(row.c);
}
