import test from 'node:test';
import assert from 'node:assert/strict';
import { averageTime, formatClock12, formatTime, parseTime, sleepDurationHours } from '../shared/time';
import {
  MIN_DAYS_NOTICE,
  analyzeCorrelation,
  describeCorrelation,
  formatR,
  linearRegression,
  pearson,
} from '../shared/stats';

const close = (a: number, b: number, eps = 1e-9) => assert.ok(Math.abs(a - b) < eps, `${a} is not close to ${b}`);

test('sleep duration: bedtime before midnight, wake next morning', () => {
  assert.equal(sleepDurationHours('23:30', '07:30'), 8);
  assert.equal(sleepDurationHours('23:30', '07:00'), 7.5);
  assert.equal(sleepDurationHours('22:00', '06:00'), 8);
});

test('sleep duration: bedtime after midnight and same-day cases', () => {
  assert.equal(sleepDurationHours('00:30', '07:00'), 6.5);
  assert.equal(sleepDurationHours('01:00', '08:00'), 7);
  assert.equal(sleepDurationHours('13:00', '15:30'), 2.5); // an afternoon nap
});

test('sleep duration: edge cases', () => {
  assert.equal(sleepDurationHours('07:00', '07:00'), 0);
  assert.equal(sleepDurationHours('23:59', '00:01'), 0.03);
  assert.throws(() => sleepDurationHours('25:00', '07:00'));
  assert.throws(() => sleepDurationHours('abc', '07:00'));
});

test('time parsing and formatting', () => {
  assert.equal(parseTime('07:30'), 450);
  assert.equal(parseTime('7:30'), null);
  assert.equal(parseTime('24:00'), null);
  assert.equal(formatTime(-30), '23:30');
  assert.equal(formatTime(24 * 60 + 15), '00:15');
  assert.equal(formatClock12('23:30'), '11:30 PM');
  assert.equal(formatClock12('00:05'), '12:05 AM');
  assert.equal(averageTime(['07:00', '08:00']), '07:30');
  assert.equal(averageTime([]), null);
});

test('pearson: perfect, inverse, undefined cases', () => {
  close(pearson([1, 2, 3, 4], [2, 4, 6, 8])!, 1);
  close(pearson([1, 2, 3, 4], [8, 6, 4, 2])!, -1);
  assert.equal(pearson([1, 2, 3], [5, 5, 5]), null);
  assert.equal(pearson([1], [1]), null);
  assert.equal(pearson([], []), null);
});

test('pearson: matches a hand-calculated value', () => {
  // x = 1..5, y = 2,1,4,3,5 -> r = 0.8
  close(pearson([1, 2, 3, 4, 5], [2, 1, 4, 3, 5])!, 0.8);
});

test('linear regression (OLS)', () => {
  const fit = linearRegression([1, 2, 3, 4], [3, 5, 7, 9])!;
  close(fit.slope, 2);
  close(fit.intercept, 1);
  assert.equal(linearRegression([2, 2, 2], [1, 2, 3]), null);
});

test('correlation labels', () => {
  assert.equal(describeCorrelation(0.78).label, 'Strong Positive Correlation');
  assert.equal(describeCorrelation(-0.55).label, 'Moderate Negative Correlation');
  assert.equal(describeCorrelation(0.25).label, 'Weak Positive Correlation');
  assert.equal(describeCorrelation(0.05).label, 'No Meaningful Correlation');
  assert.equal(formatR(0.777), '+0.78');
  assert.equal(formatR(-0.4), '-0.40');
});

test('small samples show the 7-day confidence notice until 7 days exist', () => {
  const six = analyzeCorrelation([5, 6, 7, 8, 9, 6], [1, 2, 3, 4, 5, 2]);
  assert.equal(six.sufficient, false);
  assert.equal(six.notice, MIN_DAYS_NOTICE);
  assert.equal(MIN_DAYS_NOTICE, 'Needs at least 7 days of logs for statistical confidence');
  const seven = analyzeCorrelation([5, 6, 7, 8, 9, 6, 7], [1, 2, 3, 4, 5, 2, 3]);
  assert.equal(seven.sufficient, true);
  assert.equal(seven.notice, null);
});
