import test from 'node:test';
import assert from 'node:assert/strict';
import { computeSleepDebt } from '../shared/debt';
import { recommendBedtimes } from '../shared/bedtime';
import { bedtimeHour, caffeineCurve, caffeineLevel, caffeineRemaining } from '../shared/caffeine';
import { MAX_STUDY_HOURS, MIN_SLEEP_HOURS, planExamWeek } from '../shared/exam';
import { addDays, daysBetween, isValidISODate } from '../shared/dates';
import { parseTime } from '../shared/time';
import { generateInsights } from '../shared/insights';
import { validateCaffeineInput, validateSleepInput, validateStudyInput } from '../shared/validation';
import type { Pair, SleepLog } from '../shared/types';

const night = (date: string, hours: number): SleepLog => ({
  date,
  bedtime: '23:00',
  wakeTime: '07:00',
  durationHours: hours,
  quality: 3,
});

test('sleep debt: 8 hour target, shortfall only counts short nights', () => {
  const hours = [8, 7, 6, 8.5, 5, 8, 7.5];
  const logs = hours.map((h, i) => night(addDays('2026-11-01', i), h));
  const debt = computeSleepDebt(logs, 8, 7);
  assert.equal(debt.target, 8);
  assert.equal(debt.shortfall, 6.5); // 0 + 1 + 2 + 0 + 3 + 0 + 0.5
  assert.equal(debt.surplus, 0.5);
  assert.equal(debt.net, -6);
  assert.equal(debt.nightsLogged, 7);
  assert.equal(debt.level, 'significant');
});

test('sleep debt: personalised target and a 7-night window ending at the newest log', () => {
  const logs = Array.from({ length: 10 }, (_, i) => night(addDays('2026-11-01', i), 7));
  assert.equal(computeSleepDebt(logs, 7).shortfall, 0);
  const against8 = computeSleepDebt(logs, 8, 7);
  assert.equal(against8.shortfall, 7); // only the last 7 of the 10 nights count
  assert.equal(against8.nights.length, 7);
  assert.equal(against8.endDate, '2026-11-10');
});

test('sleep debt: unlogged nights are gaps, and no logs is "unknown"', () => {
  const debt = computeSleepDebt([night('2026-11-05', 6), night('2026-11-07', 8)], 8, 7);
  assert.equal(debt.nightsLogged, 2);
  assert.equal(debt.nights.filter((n) => n.hours === null).length, 5);
  assert.equal(debt.shortfall, 2);
  assert.equal(computeSleepDebt([], 8).level, 'unknown');
});

test('optimal bedtime uses 90 minute cycles plus 15 minutes to fall asleep', () => {
  const options = recommendBedtimes('07:30', 8);
  assert.deepEqual(
    options.map((o) => [o.cycles, o.bedtime, o.sleepHours, o.recommended]),
    [
      [6, '22:15', 9, false],
      [5, '23:45', 7.5, true],
      [4, '01:15', 6, false],
    ],
  );
});

test('caffeine half-life is 5 hours', () => {
  const doses = [{ time: '08:00', mg: 100 }];
  assert.ok(Math.abs(caffeineRemaining(doses, 13) - 50) < 1e-9);
  assert.ok(Math.abs(caffeineRemaining(doses, 18) - 25) < 1e-9);
  assert.equal(caffeineRemaining(doses, 7), 0); // not drunk yet
  assert.equal(bedtimeHour('23:30'), 23.5);
  assert.equal(bedtimeHour('00:30'), 24.5);
  assert.equal(caffeineLevel(0), 'none');
  assert.equal(caffeineLevel(80), 'high');
  const curve = caffeineCurve(doses);
  assert.equal(curve[0].hour, 6);
  assert.equal(curve[curve.length - 1].hour, 30);
});

test('exam planner never exceeds 8 study hours or plans under 7 hours of sleep', () => {
  const plan = planExamWeek({
    startDate: '2026-12-01',
    days: 7,
    wakeTime: '07:00',
    sleepHours: 4, // asked for far too little sleep
    maxStudyHours: 14, // asked for far too much study
    subjects: [
      { name: 'Algorithms', examDate: '2026-12-04', difficulty: 3 },
      { name: 'Calculus', examDate: '2026-12-06', difficulty: 2 },
      { name: 'Databases', examDate: '2026-12-07', difficulty: 1 },
    ],
  });
  assert.equal(plan.length, 7);
  for (const day of plan) {
    assert.ok(day.studyHours <= MAX_STUDY_HOURS, `${day.date}: ${day.studyHours} study hours`);
    assert.ok(day.sleepHours >= MIN_SLEEP_HOURS, `${day.date}: ${day.sleepHours} sleep hours`);
    const blockSum = day.blocks.reduce((s, b) => s + b.hours, 0);
    assert.ok(Math.abs(blockSum - day.studyHours) < 1e-9);
  }
  assert.equal(plan[0].studyHours, 8); // a normal full day uses the cap, not more
});

test('exam planner: lighter days around exams, rest after the last one', () => {
  const plan = planExamWeek({
    startDate: '2026-12-01',
    days: 5,
    wakeTime: '07:00',
    sleepHours: 8,
    subjects: [{ name: 'Algorithms', examDate: '2026-12-03', difficulty: 3 }],
  });
  assert.equal(plan[0].studyHours, 8);
  assert.ok(plan[1].studyHours <= 6, 'day before an exam is capped at 6 h');
  assert.ok(plan[2].studyHours <= 2, 'exam day is light review only');
  assert.deepEqual(plan[2].exams, ['Algorithms']);
  assert.equal(plan[3].studyHours, 0);
  assert.equal(plan[4].studyHours, 0);
});

test('exam planner: blocks do not overlap and finish 2 hours before bedtime', () => {
  const plan = planExamWeek({
    startDate: '2026-12-01',
    days: 3,
    wakeTime: '09:30',
    sleepHours: 9,
    subjects: [
      { name: 'Physics', examDate: '2026-12-09', difficulty: 2 },
      { name: 'Literature', examDate: '2026-12-10', difficulty: 3 },
    ],
  });
  for (const day of plan) {
    const wake = parseTime(day.wakeTime)!;
    const bedAbs = wake + 24 * 60 - day.sleepHours * 60;
    let previousEnd = -1;
    for (const b of day.blocks) {
      const s = parseTime(b.start)!;
      let e = parseTime(b.end)!;
      if (e <= s) e += 24 * 60;
      assert.ok(s >= previousEnd, 'blocks overlap');
      assert.ok(e <= bedAbs - 120, 'study runs too close to bedtime');
      previousEnd = e;
    }
  }
});

test('dates', () => {
  assert.equal(addDays('2026-11-30', 1), '2026-12-01');
  assert.equal(addDays('2026-03-01', -1), '2026-02-28');
  assert.equal(daysBetween('2026-11-10', '2026-11-15'), 5);
  assert.equal(isValidISODate('2026-02-30'), false);
  assert.equal(isValidISODate('2026-11-15'), true);
});

test('insight: days after 7.5+ hours vs the rest', () => {
  const mk = (date: string, sleepHours: number, focus: number): Pair => ({
    date,
    sleepHours,
    focus,
    quality: 3,
    hoursStudied: 4,
    score: null,
  });
  const pairs = [mk('a', 8, 5), mk('b', 8.5, 4), mk('c', 6, 3), mk('d', 5.5, 2), mk('e', 6.5, 3)];
  const debt = computeSleepDebt([], 8);
  const insight = generateInsights(pairs, debt).find((i) => i.id === 'rested-vs-other')!;
  // rested average 4.5, others average 2.67 -> +69%
  assert.match(insight.text, /^Days following 7\.5\+ hours of sleep saw 69% higher study focus/);
});

test('validation: sleep', () => {
  const ok = validateSleepInput({ date: '2026-11-15', bedtime: '23:30', wakeTime: '07:30', quality: 4 });
  assert.ok(ok.ok && ok.value.durationHours === 8);
  assert.equal(validateSleepInput({ date: '2026-11-15', bedtime: '23:30', wakeTime: '23:30', quality: 4 }).ok, false);
  assert.equal(validateSleepInput({ date: '2026-11-15', bedtime: '23:30', wakeTime: '07:30', quality: 6 }).ok, false);
  assert.equal(validateSleepInput({ date: 'nope', bedtime: '23:30', wakeTime: '07:30', quality: 3 }).ok, false);
  assert.equal(validateSleepInput({ date: '2026-11-15', bedtime: '06:00', wakeTime: '05:00', quality: 3 }).ok, false); // 23 h
  assert.equal(validateSleepInput(null).ok, false);
});

test('validation: study and caffeine', () => {
  const ok = validateStudyInput({ date: '2026-11-15', hoursStudied: 4.5, subjects: [' Algorithms '], focus: 5, score: null });
  assert.ok(ok.ok && ok.value.subjects[0] === 'Algorithms' && ok.value.score === null);
  assert.equal(validateStudyInput({ date: '2026-11-15', hoursStudied: 4, subjects: [], focus: 3 }).ok, false);
  assert.equal(validateStudyInput({ date: '2026-11-15', hoursStudied: 17, subjects: ['x'], focus: 3 }).ok, false);
  assert.equal(validateStudyInput({ date: '2026-11-15', hoursStudied: 2, subjects: ['x'], focus: 0 }).ok, false);
  assert.equal(validateStudyInput({ date: '2026-11-15', hoursStudied: 2, subjects: ['x'], focus: 3, score: 101 }).ok, false);
  assert.equal(validateCaffeineInput({ date: '2026-11-15', time: '09:00', drink: 'Coffee', mg: 95 }).ok, true);
  assert.equal(validateCaffeineInput({ date: '2026-11-15', time: '9am', drink: 'Coffee', mg: 95 }).ok, false);
});
