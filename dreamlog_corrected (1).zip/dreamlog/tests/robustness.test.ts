import test from 'node:test';
import assert from 'node:assert/strict';
import type { AddressInfo } from 'node:net';
import { openDb, preparedStatementCount, transaction } from '../server/src/db';
import { createApp, type AppOptions } from '../server/src/app';
import { seedDatabase } from '../server/src/seed';
import { countSleep } from '../server/src/repo';
import { CircuitBreaker } from '../server/src/infra/circuitBreaker';
import { LruCache } from '../server/src/infra/cache';
import { AppError, ServiceUnavailableError, toAppError } from '../server/src/infra/errors';
import { autoHolt, detectAnomalies, forecast, median, projectDebt } from '../shared/forecast';

const TODAY = '2026-11-15';

async function withServer(opts: AppOptions, fn: (base: string) => Promise<void>, db = openDb(':memory:')) {
  const server = createApp(db, opts).listen(0);
  await new Promise((r) => server.once('listening', r));
  try {
    await fn(`http://127.0.0.1:${(server.address() as AddressInfo).port}/api`);
  } finally {
    server.close();
  }
}

// ---- circuit breaker ----
test('circuit breaker opens after N failures, fails fast, then recovers via half-open', () => {
  let t = 0;
  const b = new CircuitBreaker('db', { failureThreshold: 2, cooldownMs: 1000, now: () => t });
  const boom = () => {
    throw new Error('disk I/O');
  };
  assert.throws(() => b.exec(boom));
  assert.throws(() => b.exec(boom));
  assert.equal(b.getState(), 'OPEN');
  assert.throws(() => b.exec(() => 1), ServiceUnavailableError);
  t = 1000;
  assert.equal(b.getState(), 'HALF_OPEN');
  assert.equal(b.exec(() => 42), 42);
  assert.equal(b.getState(), 'CLOSED');
});

test('circuit breaker re-opens immediately if the half-open trial fails', () => {
  let t = 0;
  const b = new CircuitBreaker('db', { failureThreshold: 1, cooldownMs: 10, now: () => t });
  assert.throws(() => b.exec(() => { throw new Error('x'); }));
  t = 10;
  assert.throws(() => b.exec(() => { throw new Error('still down'); }));
  assert.equal(b.getState(), 'OPEN');
});

// ---- cache ----
test('LRU cache: hits, TTL expiry, eviction and invalidation', () => {
  let t = 0;
  const c = new LruCache<number>(2, 100, () => t);
  let calls = 0;
  const compute = () => ++calls;
  c.getOrCompute('a', compute);
  c.getOrCompute('a', compute);
  assert.equal(calls, 1);
  c.set('b', 2);
  c.set('c', 3); // evicts least-recently used 'a'
  assert.equal(c.get('a'), undefined);
  t = 200;
  assert.equal(c.get('b'), undefined); // expired
  c.set('d', 4);
  c.invalidate();
  assert.equal(c.get('d'), undefined);
});

// ---- error mapping ----
test('low-level errors map to specific status codes', () => {
  assert.equal(toAppError(new Error('database is locked')).status, 503);
  assert.equal(toAppError(new Error('CHECK constraint failed: quality')).status, 400);
  assert.equal(toAppError(new Error('UNIQUE constraint failed')).status, 409);
  assert.equal(toAppError({ type: 'entity.parse.failed' }).status, 400);
  assert.equal(toAppError({ type: 'entity.too.large' }).status, 413);
  assert.equal(toAppError(new Error('???')).status, 500);
  assert.ok(toAppError(new AppError('x', 418, 'TEAPOT')).status === 418);
});

// ---- db ----
test('prepared statements are compiled once and reused', () => {
  const db = openDb(':memory:');
  seedDatabase(db, TODAY);
  const n = preparedStatementCount(db);
  seedDatabase(db, TODAY, true);
  assert.equal(preparedStatementCount(db), n);
});

test('transaction rolls back on error', () => {
  const db = openDb(':memory:');
  assert.throws(() =>
    transaction(db, () => {
      db.exec("INSERT INTO settings (key, value) VALUES ('k', 'v')");
      throw new Error('fail');
    }),
  );
  assert.equal((db.prepare('SELECT COUNT(*) AS c FROM settings').get() as { c: number }).c, 0);
});

// ---- HTTP integration ----
test('API returns typed errors with request ids and security headers', async () => {
  await withServer({}, async (base) => {
    const bad = await fetch(`${base}/sleep`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{oops' });
    assert.equal(bad.status, 400);
    const badBody = (await bad.json()) as { code: string; requestId: string };
    assert.equal(badBody.code, 'BAD_JSON');
    assert.ok(badBody.requestId);
    assert.equal(bad.headers.get('x-content-type-options'), 'nosniff');
    assert.equal(bad.headers.get('x-powered-by'), null);

    const invalid = await fetch(`${base}/sleep`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
    const ib = (await invalid.json()) as { code: string; errors: string[] };
    assert.equal(invalid.status, 400);
    assert.equal(ib.code, 'VALIDATION_FAILED');
    assert.ok(ib.errors.length > 0);

    const missing = await fetch(`${base}/sleep/2020-01-01`, { method: 'DELETE' });
    assert.equal(missing.status, 404);
    assert.equal(((await missing.json()) as { code: string }).code, 'NOT_FOUND');

    const big = await fetch(`${base}/sleep`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ x: 'a'.repeat(30_000) }) });
    assert.equal(big.status, 413);
  });
});

test('rate limiter returns 429 with Retry-After', async () => {
  await withServer({ rateLimit: { capacity: 3, refillPerSec: 0.01 } }, async (base) => {
    const codes: number[] = [];
    for (let i = 0; i < 5; i++) codes.push((await fetch(`${base}/settings`)).status);
    assert.deepEqual(codes.slice(0, 3), [200, 200, 200]);
    const last = await fetch(`${base}/settings`);
    assert.equal(last.status, 429);
    assert.ok(Number(last.headers.get('retry-after')) >= 1);
  });
});

test('analytics are cached and invalidated by writes', async () => {
  const db = openDb(':memory:');
  seedDatabase(db, TODAY);
  await withServer({}, async (base) => {
    await fetch(`${base}/analytics?today=${TODAY}`);
    await fetch(`${base}/analytics?today=${TODAY}`);
    let h = (await (await fetch(`${base}/health`)).json()) as { cache: { hits: number } };
    assert.ok(h.cache.hits >= 1);
    const before = (await (await fetch(`${base}/analytics?today=${TODAY}`)).json()) as { pairs: unknown[] };
    await fetch(`${base}/sleep/2026-11-10`, { method: 'DELETE' });
    const after = (await (await fetch(`${base}/analytics?today=${TODAY}`)).json()) as { pairs: unknown[] };
    assert.equal(after.pairs.length, before.pairs.length - 1);
    h = (await (await fetch(`${base}/health`)).json()) as { cache: { hits: number } };
    assert.ok(h.cache.hits >= 2);
  }, db);
});

test('broken database trips the breaker and the API fails fast with 503', async () => {
  const db = openDb(':memory:');
  db.close(); // simulate a dead database
  await withServer({ breaker: { failureThreshold: 2, cooldownMs: 60_000 } }, async (base) => {
    assert.equal((await fetch(`${base}/sleep`)).status, 500);
    assert.equal((await fetch(`${base}/sleep`)).status, 500);
    const fast = await fetch(`${base}/sleep`);
    assert.equal(fast.status, 503);
    assert.ok(fast.headers.get('retry-after'));
    assert.equal((await fetch(`${base}/health`)).status, 503);
  }, db);
});

// ---- forecasting ----
test('median handles odd and even lengths', () => {
  assert.equal(median([3, 1, 2]), 2);
  assert.equal(median([4, 1, 2, 3]), 2.5);
});

test('Holt forecast follows a clear linear trend', () => {
  const series = [5, 5.5, 6, 6.5, 7, 7.5, 8];
  const m = autoHolt(series);
  assert.ok(m.sse < 0.01);
  const f = forecast(series, 1);
  assert.ok(Math.abs(f[0].value - 8.5) < 0.1, String(f[0].value));
  assert.ok(f[0].low <= f[0].value && f[0].value <= f[0].high);
});

test('forecast is clamped and needs at least 4 nights', () => {
  assert.deepEqual(forecast([7, 7, 7]), []);
  const f = forecast([12, 13, 14, 14, 14], 3);
  assert.ok(f.every((p) => p.value <= 14 && p.low >= 0));
});

test('MAD anomaly detection flags the all-nighter but not normal variation', () => {
  const series = [7, 7.5, 6.8, 7.2, 7.1, 2, 7.3, 6.9];
  const a = detectAnomalies(series);
  assert.equal(a.length, 1);
  assert.equal(a[0].index, 5);
  assert.equal(a[0].direction, 'low');
});

test('projected debt accumulates shortfall and never goes negative', () => {
  const pts = [6, 6, 10].map((v, i) => ({ step: i + 1, value: v, low: v, high: v }));
  assert.deepEqual(projectDebt(1, pts, 8), [3, 5, 3]);
  assert.deepEqual(projectDebt(0, [{ step: 1, value: 10, low: 10, high: 10 }], 8), [0]);
});

test('forecast endpoint works on seed data', async () => {
  const db = openDb(':memory:');
  seedDatabase(db, TODAY);
  assert.equal(countSleep(db), 21);
  await withServer({}, async (base) => {
    const r = (await (await fetch(`${base}/forecast?today=${TODAY}`)).json()) as { nextNights: unknown[]; basedOnNights: number };
    assert.equal(r.nextNights.length, 3);
    assert.equal(r.basedOnNights, 21);
  }, db);
});
